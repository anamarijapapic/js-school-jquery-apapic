# WordPress MySQL database migration
#
# Generated: Thursday 15. December 2022 10:32 UTC
# Hostname: db
# Database: `wp`
# URL: //js-school-wp-1.test
# Path: /var/www/html
# Tables: wp_2_commentmeta, wp_2_comments, wp_2_links, wp_2_options, wp_2_postmeta, wp_2_posts, wp_2_term_relationships, wp_2_term_taxonomy, wp_2_termmeta, wp_2_terms, wp_2_yoast_indexable, wp_2_yoast_indexable_hierarchy, wp_2_yoast_migrations, wp_2_yoast_primary_term, wp_2_yoast_seo_links, wp_blogmeta, wp_blogs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_registration_log, wp_signups, wp_site, wp_sitemeta, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, organization, page, post, team-member
# Protocol: https
# Multisite: true
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_2_commentmeta`
#

DROP TABLE IF EXISTS `wp_2_commentmeta`;


#
# Table structure of table `wp_2_commentmeta`
#

CREATE TABLE `wp_2_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_commentmeta`
#

#
# End of data contents of table `wp_2_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_comments`
#

DROP TABLE IF EXISTS `wp_2_comments`;


#
# Table structure of table `wp_2_comments`
#

CREATE TABLE `wp_2_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_comments`
#
INSERT INTO `wp_2_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://js-school-wp.test/', '', '2022-12-12 13:22:33', '2022-12-12 13:22:33', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_2_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_links`
#

DROP TABLE IF EXISTS `wp_2_links`;


#
# Table structure of table `wp_2_links`
#

CREATE TABLE `wp_2_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_links`
#

#
# End of data contents of table `wp_2_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_options`
#

DROP TABLE IF EXISTS `wp_2_options`;


#
# Table structure of table `wp_2_options`
#

CREATE TABLE `wp_2_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_options`
#
INSERT INTO `wp_2_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://js-school-wp-2.test', 'yes'),
(2, 'home', 'http://js-school-wp-2.test', 'yes'),
(3, 'blogname', 'JS School WP 2', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'anamarija.papic@agilo.co', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'js-school-wp', 'yes'),
(41, 'stylesheet', 'js-school-wp', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:41:"debug-bar-rewrite-rules/rewrite-rules.php";s:17:"umdbrr_deactivate";}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '0', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1686403353', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'WPLANG', '', 'yes'),
(100, 'wp_2_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:10:"copy_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:39:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;s:10:"copy_posts";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}}', 'yes'),
(101, 'post_count', '1', 'yes') ;
INSERT INTO `wp_2_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(104, 'cron', 'a:7:{i:1670851450;a:2:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1670851588;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1670851648;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1670852385;a:1:{s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1670852420;a:1:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1670937850;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(130, 'rewrite_rules', 'a:143:{s:15:"team-members/?$";s:31:"index.php?post_type=team-member";s:45:"team-members/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=team-member&feed=$matches[1]";s:40:"team-members/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=team-member&feed=$matches[1]";s:32:"team-members/page/([0-9]{1,})/?$";s:49:"index.php?post_type=team-member&paged=$matches[1]";s:16:"organizations/?$";s:32:"index.php?post_type=organization";s:46:"organizations/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=organization&feed=$matches[1]";s:41:"organizations/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=organization&feed=$matches[1]";s:33:"organizations/page/([0-9]{1,})/?$";s:50:"index.php?post_type=organization&paged=$matches[1]";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"team-members/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"team-members/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"team-members/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"team-members/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"team-members/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"team-members/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"team-members/([^/]+)/embed/?$";s:44:"index.php?team-member=$matches[1]&embed=true";s:33:"team-members/([^/]+)/trackback/?$";s:38:"index.php?team-member=$matches[1]&tb=1";s:53:"team-members/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?team-member=$matches[1]&feed=$matches[2]";s:48:"team-members/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?team-member=$matches[1]&feed=$matches[2]";s:41:"team-members/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?team-member=$matches[1]&paged=$matches[2]";s:48:"team-members/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?team-member=$matches[1]&cpage=$matches[2]";s:37:"team-members/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?team-member=$matches[1]&page=$matches[2]";s:29:"team-members/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"team-members/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"team-members/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"team-members/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"team-members/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"team-members/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:41:"organizations/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"organizations/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"organizations/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"organizations/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"organizations/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"organizations/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"organizations/([^/]+)/embed/?$";s:45:"index.php?organization=$matches[1]&embed=true";s:34:"organizations/([^/]+)/trackback/?$";s:39:"index.php?organization=$matches[1]&tb=1";s:54:"organizations/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?organization=$matches[1]&feed=$matches[2]";s:49:"organizations/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?organization=$matches[1]&feed=$matches[2]";s:42:"organizations/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?organization=$matches[1]&paged=$matches[2]";s:49:"organizations/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?organization=$matches[1]&cpage=$matches[2]";s:38:"organizations/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?organization=$matches[1]&page=$matches[2]";s:30:"organizations/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"organizations/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"organizations/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"organizations/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"organizations/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"organizations/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(131, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1670852487;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(132, 'wpseo', 'a:97:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:1;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:26:"permalink_settings_changed";s:29:"indexables_indexing_completed";b:1;s:13:"index_now_key";s:0:"";s:7:"version";s:5:"19.10";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:22:"show_onboarding_notice";b:0;s:18:"first_activated_on";b:0;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:12:"/%postname%/";s:8:"home_url";s:0:"";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:0;s:34:"dismiss_premium_deactivated_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:0;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:28:"wordproof_integration_active";b:0;s:29:"wordproof_integration_changed";b:0;s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1670852420;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";}', 'yes'),
(133, 'wpseo_titles', 'a:145:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:17:"title-team-member";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:20:"metadesc-team-member";s:0:"";s:19:"noindex-team-member";b:0;s:30:"display-metabox-pt-team-member";b:1;s:30:"post_types-team-member-maintax";i:0;s:28:"schema-page-type-team-member";s:7:"WebPage";s:31:"schema-article-type-team-member";s:4:"None";s:24:"social-title-team-member";s:9:"%%title%%";s:30:"social-description-team-member";s:0:"";s:28:"social-image-url-team-member";s:0:"";s:27:"social-image-id-team-member";i:0;s:27:"title-ptarchive-team-member";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:30:"metadesc-ptarchive-team-member";s:0:"";s:29:"bctitle-ptarchive-team-member";s:0:"";s:29:"noindex-ptarchive-team-member";b:0;s:34:"social-title-ptarchive-team-member";s:21:"%%pt_plural%% Archive";s:40:"social-description-ptarchive-team-member";s:0:"";s:38:"social-image-url-ptarchive-team-member";s:0:"";s:37:"social-image-id-ptarchive-team-member";i:0;s:18:"title-organization";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-organization";s:0:"";s:20:"noindex-organization";b:0;s:31:"display-metabox-pt-organization";b:1;s:31:"post_types-organization-maintax";i:0;s:29:"schema-page-type-organization";s:7:"WebPage";s:32:"schema-article-type-organization";s:4:"None";s:25:"social-title-organization";s:9:"%%title%%";s:31:"social-description-organization";s:0:"";s:29:"social-image-url-organization";s:0:"";s:28:"social-image-id-organization";i:0;s:28:"title-ptarchive-organization";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:31:"metadesc-ptarchive-organization";s:0:"";s:30:"bctitle-ptarchive-organization";s:0:"";s:30:"noindex-ptarchive-organization";b:0;s:35:"social-title-ptarchive-organization";s:21:"%%pt_plural%% Archive";s:41:"social-description-ptarchive-organization";s:0:"";s:39:"social-image-url-ptarchive-organization";s:0:"";s:38:"social-image-id-ptarchive-organization";i:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'yes'),
(134, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'yes'),
(135, 'acf_version', '6.0.5', 'yes'),
(136, 'bodhi_svgs_plugin_version', '2.5.3', 'yes'),
(137, 'bodhi_svgs_settings', 'a:4:{s:22:"sanitize_svg_front_end";s:2:"on";s:8:"restrict";a:1:{i:0;s:13:"administrator";}s:12:"sanitize_svg";s:2:"on";s:24:"sanitize_on_upload_roles";a:2:{i:0;s:13:"administrator";i:1;s:6:"editor";}}', 'yes'),
(138, 'yoast_migrations_free', 'a:1:{s:7:"version";s:5:"19.10";}', 'yes'),
(139, 'debug_bar_rewrite_rules_filters_list', 'a:3:{s:4:"list";a:13:{i:0;s:22:"category_rewrite_rules";i:1;s:25:"post_format_rewrite_rules";i:2;s:25:"team-member_rewrite_rules";i:3;s:26:"organization_rewrite_rules";i:4;s:18:"post_rewrite_rules";i:5;s:18:"date_rewrite_rules";i:6;s:18:"root_rewrite_rules";i:7;s:22:"comments_rewrite_rules";i:8;s:20:"search_rewrite_rules";i:9;s:20:"author_rewrite_rules";i:10;s:18:"page_rewrite_rules";i:11;s:17:"tag_rewrite_rules";i:12;s:19:"rewrite_rules_array";}s:5:"count";i:0;s:7:"details";a:0:{}}', 'yes'),
(140, 'duplicate_post_show_notice', '1', 'yes'),
(141, 'duplicate_post_copytitle', '1', 'yes'),
(142, 'duplicate_post_copydate', '0', 'yes'),
(143, 'duplicate_post_copystatus', '0', 'yes'),
(144, 'duplicate_post_copyslug', '0', 'yes'),
(145, 'duplicate_post_copyexcerpt', '1', 'yes'),
(146, 'duplicate_post_copycontent', '1', 'yes'),
(147, 'duplicate_post_copythumbnail', '1', 'yes'),
(148, 'duplicate_post_copytemplate', '1', 'yes'),
(149, 'duplicate_post_copyformat', '1', 'yes'),
(150, 'duplicate_post_copyauthor', '0', 'yes'),
(151, 'duplicate_post_copypassword', '0', 'yes'),
(152, 'duplicate_post_copyattachments', '0', 'yes'),
(153, 'duplicate_post_copychildren', '0', 'yes'),
(154, 'duplicate_post_copycomments', '0', 'yes'),
(155, 'duplicate_post_copymenuorder', '1', 'yes'),
(156, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(157, 'duplicate_post_blacklist', '', 'yes'),
(158, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:"post";i:1;s:4:"page";}', 'yes'),
(159, 'duplicate_post_show_original_column', '0', 'yes'),
(160, 'duplicate_post_show_original_in_post_states', '0', 'yes'),
(161, 'duplicate_post_show_original_meta_box', '0', 'yes'),
(162, 'duplicate_post_show_link', 'a:3:{s:9:"new_draft";s:1:"1";s:5:"clone";s:1:"1";s:17:"rewrite_republish";s:1:"1";}', 'yes'),
(163, 'duplicate_post_show_link_in', 'a:4:{s:3:"row";s:1:"1";s:8:"adminbar";s:1:"1";s:9:"submitbox";s:1:"1";s:11:"bulkactions";s:1:"1";}', 'yes'),
(164, 'duplicate_post_version', '4.5', 'yes'),
(191, 'current_theme', 'JS School WP', 'yes'),
(192, 'theme_mods_js-school-wp', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(193, 'theme_switched', '', 'yes'),
(222, 'fresh_site', '0', 'yes') ;

#
# End of data contents of table `wp_2_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_postmeta`
#

DROP TABLE IF EXISTS `wp_2_postmeta`;


#
# Table structure of table `wp_2_postmeta`
#

CREATE TABLE `wp_2_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_postmeta`
#
INSERT INTO `wp_2_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(4, 4, '_yoast_wpseo_wordproof_timestamp', ''),
(5, 4, 'inline_featured_image', '0'),
(6, 4, '_edit_lock', '1670917811:1'),
(7, 2, '_edit_lock', '1671091456:1'),
(8, 2, '_edit_last', '1') ;

#
# End of data contents of table `wp_2_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_posts`
#

DROP TABLE IF EXISTS `wp_2_posts`;


#
# Table structure of table `wp_2_posts`
#

CREATE TABLE `wp_2_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_posts`
#
INSERT INTO `wp_2_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-12-12 13:22:33', '2022-12-12 13:22:33', 'Welcome to <a href="https://js-school-wp.test/">JS School Sites</a>. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-12-12 13:22:33', '2022-12-12 13:22:33', '', 0, 'http://js2.js-school-wp.test/?p=1', 0, 'post', '', 1),
(2, 1, '2022-12-12 13:22:33', '2022-12-12 13:22:33', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="https://js2.js-school-wp.test/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2022-12-15 08:05:17', '2022-12-15 08:05:17', '', 0, 'http://js2.js-school-wp.test/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-12-12 13:26:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-12-12 13:26:28', '0000-00-00 00:00:00', '', 0, 'https://js-school-wp-2.test/?p=3', 0, 'post', '', 0),
(4, 1, '2022-12-13 07:52:19', '2022-12-13 07:52:19', '', 'Autocomplete menu & CORS endpoint', '', 'publish', 'closed', 'closed', '', 'autocomplete-menu-cors-endpoint', '', '', '2022-12-13 07:52:19', '2022-12-13 07:52:19', '', 0, 'https://js-school-wp-2.test/?page_id=4', 0, 'page', '', 0),
(5, 1, '2022-12-13 07:52:19', '2022-12-13 07:52:19', '', 'Autocomplete menu & CORS endpoint', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2022-12-13 07:52:19', '2022-12-13 07:52:19', '', 4, 'https://js-school-wp-2.test/?p=5', 0, 'revision', '', 0),
(6, 1, '2022-12-15 08:04:49', '2022-12-15 08:04:49', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote">\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote">\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="https://js2.js-school-wp.test/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Homepage', '', 'inherit', 'closed', 'closed', '', '2-autosave-v1', '', '', '2022-12-15 08:04:49', '2022-12-15 08:04:49', '', 2, 'https://js-school-wp-2.test/?p=6', 0, 'revision', '', 0),
(7, 1, '2022-12-15 08:05:17', '2022-12-15 08:05:17', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="https://js2.js-school-wp.test/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Homepage', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-12-15 08:05:17', '2022-12-15 08:05:17', '', 2, 'https://js-school-wp-2.test/?p=7', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_2_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_term_relationships`
#

DROP TABLE IF EXISTS `wp_2_term_relationships`;


#
# Table structure of table `wp_2_term_relationships`
#

CREATE TABLE `wp_2_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_term_relationships`
#
INSERT INTO `wp_2_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0) ;

#
# End of data contents of table `wp_2_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_2_term_taxonomy`;


#
# Table structure of table `wp_2_term_taxonomy`
#

CREATE TABLE `wp_2_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_term_taxonomy`
#
INSERT INTO `wp_2_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_2_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_termmeta`
#

DROP TABLE IF EXISTS `wp_2_termmeta`;


#
# Table structure of table `wp_2_termmeta`
#

CREATE TABLE `wp_2_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_termmeta`
#

#
# End of data contents of table `wp_2_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_terms`
#

DROP TABLE IF EXISTS `wp_2_terms`;


#
# Table structure of table `wp_2_terms`
#

CREATE TABLE `wp_2_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_terms`
#
INSERT INTO `wp_2_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0) ;

#
# End of data contents of table `wp_2_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_2_yoast_indexable`;


#
# Table structure of table `wp_2_yoast_indexable`
#

CREATE TABLE `wp_2_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext DEFAULT NULL,
  `permalink_hash` varchar(40) DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) NOT NULL,
  `object_sub_type` varchar(32) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `breadcrumb_title` text DEFAULT NULL,
  `post_status` varchar(20) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext DEFAULT NULL,
  `primary_focus_keyword` varchar(191) DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text DEFAULT NULL,
  `twitter_image` longtext DEFAULT NULL,
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image_id` varchar(191) DEFAULT NULL,
  `twitter_image_source` text DEFAULT NULL,
  `open_graph_title` text DEFAULT NULL,
  `open_graph_description` longtext DEFAULT NULL,
  `open_graph_image` longtext DEFAULT NULL,
  `open_graph_image_id` varchar(191) DEFAULT NULL,
  `open_graph_image_source` text DEFAULT NULL,
  `open_graph_image_meta` mediumtext DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 2,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  `schema_page_type` varchar(64) DEFAULT NULL,
  `schema_article_type` varchar(64) DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_indexable`
#
INSERT INTO `wp_2_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'https://js-school-wp-2.test/', '28:a4f966a4b1b5896f611c3da3a139ca49', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', '', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:39:45', '2022-12-15 08:05:22', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-15 08:05:17', '2022-12-12 13:22:33'),
(2, 'https://js-school-wp-2.test/author/anamarija/', '45:baa970b05a1cac61bba8341fb08765ff', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://secure.gravatar.com/avatar/0da7ff9fa2df592ba150b037d8653d22?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://secure.gravatar.com/avatar/0da7ff9fa2df592ba150b037d8653d22?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2022-12-12 13:40:26', '2022-12-15 08:05:22', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-15 08:05:17', '2022-12-12 13:22:33'),
(3, 'https://js-school-wp-2.test/', '28:a4f966a4b1b5896f611c3da3a139ca49', 2, 'post', 'page', 1, 0, NULL, NULL, 'Homepage', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-12 13:40:26', '2022-12-15 08:06:22', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-15 08:05:17', '2022-12-12 13:22:33'),
(4, 'https://js-school-wp-2.test/hello-world/', '40:eb9720d3ddc5dd1eca217a0d70de336a', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-12 13:40:26', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-12 13:22:33', '2022-12-12 13:22:33'),
(5, 'https://js-school-wp-2.test/category/uncategorized/', '51:8f154d4f12106a1e3f9a0ff5d25e2bd8', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Uncategorized', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-12 13:40:26', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-12 13:22:33', '2022-12-12 13:22:33'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:40:26', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:40:26', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:40:26', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'https://js-school-wp-2.test/team-members/', '41:b66640eb7441b338653af60e00a67646', NULL, 'post-type-archive', 'team-member', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Team Members', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:41:56', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL),
(10, 'https://js-school-wp-2.test/organizations/', '42:08f31e3172899a7845c716418f5be186', NULL, 'post-type-archive', 'organization', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Organizations', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:41:56', '2022-12-12 13:41:56', 2, NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL),
(11, 'https://js-school-wp-2.test/autocomplete-menu-cors-endpoint/', '60:ca64932a940c9f584693d5aaa41db7c8', 4, 'post', 'page', 1, 0, NULL, NULL, 'Autocomplete menu &#038; CORS endpoint', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-13 07:52:19', '2022-12-13 07:52:19', 2, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-13 07:52:19', '2022-12-13 07:52:19') ;

#
# End of data contents of table `wp_2_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_2_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_2_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_2_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 2,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_indexable_hierarchy`
#
INSERT INTO `wp_2_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(1, 0, 0, 2),
(3, 0, 0, 2),
(4, 0, 0, 2),
(5, 0, 0, 2),
(9, 0, 0, 2),
(11, 0, 0, 2) ;

#
# End of data contents of table `wp_2_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_2_yoast_migrations`;


#
# Table structure of table `wp_2_yoast_migrations`
#

CREATE TABLE `wp_2_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_2_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_migrations`
#
INSERT INTO `wp_2_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# End of data contents of table `wp_2_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_2_yoast_primary_term`;


#
# Table structure of table `wp_2_yoast_primary_term`
#

CREATE TABLE `wp_2_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_primary_term`
#

#
# End of data contents of table `wp_2_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_2_yoast_seo_links`;


#
# Table structure of table `wp_2_yoast_seo_links`
#

CREATE TABLE `wp_2_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_2_yoast_seo_links`
#
INSERT INTO `wp_2_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(1, 'https://js2.js-school-wp.test/wp-admin/', 2, NULL, 'external', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'https://js-school-wp.test/', 1, NULL, 'external', 4, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_2_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogmeta`
#

DROP TABLE IF EXISTS `wp_blogmeta`;


#
# Table structure of table `wp_blogmeta`
#

CREATE TABLE `wp_blogmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blogmeta`
#

#
# End of data contents of table `wp_blogmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogs`
#

DROP TABLE IF EXISTS `wp_blogs`;


#
# Table structure of table `wp_blogs`
#

CREATE TABLE `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT 0,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT 1,
  `archived` tinyint(2) NOT NULL DEFAULT 0,
  `mature` tinyint(2) NOT NULL DEFAULT 0,
  `spam` tinyint(2) NOT NULL DEFAULT 0,
  `deleted` tinyint(2) NOT NULL DEFAULT 0,
  `lang_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blogs`
#
INSERT INTO `wp_blogs` ( `blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'js-school-wp-1.test', '/', '2022-12-12 13:15:59', '2022-12-13 07:50:34', 1, 0, 0, 0, 0, 0),
(2, 1, 'js-school-wp-2.test', '/', '2022-12-12 13:22:32', '2022-12-15 08:05:17', 1, 0, 0, 0, 0, 0) ;

#
# End of data contents of table `wp_blogs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-11-23 12:53:39', '2022-11-23 12:53:39', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=967 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://js-school-wp-1.test', 'yes'),
(2, 'home', 'https://js-school-wp-1.test', 'yes'),
(3, 'blogname', 'JS School WP 1', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'anamarija.papic@agilo.co', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:148:{s:15:"team-members/?$";s:31:"index.php?post_type=team-member";s:45:"team-members/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=team-member&feed=$matches[1]";s:40:"team-members/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=team-member&feed=$matches[1]";s:32:"team-members/page/([0-9]{1,})/?$";s:49:"index.php?post_type=team-member&paged=$matches[1]";s:16:"organizations/?$";s:32:"index.php?post_type=organization";s:46:"organizations/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=organization&feed=$matches[1]";s:41:"organizations/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=organization&feed=$matches[1]";s:33:"organizations/page/([0-9]{1,})/?$";s:50:"index.php?post_type=organization&paged=$matches[1]";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"team-members/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"team-members/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"team-members/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"team-members/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"team-members/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"team-members/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"team-members/([^/]+)/embed/?$";s:44:"index.php?team-member=$matches[1]&embed=true";s:33:"team-members/([^/]+)/trackback/?$";s:38:"index.php?team-member=$matches[1]&tb=1";s:53:"team-members/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?team-member=$matches[1]&feed=$matches[2]";s:48:"team-members/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?team-member=$matches[1]&feed=$matches[2]";s:41:"team-members/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?team-member=$matches[1]&paged=$matches[2]";s:48:"team-members/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?team-member=$matches[1]&cpage=$matches[2]";s:37:"team-members/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?team-member=$matches[1]&page=$matches[2]";s:29:"team-members/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"team-members/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"team-members/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"team-members/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"team-members/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"team-members/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:41:"organizations/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"organizations/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"organizations/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"organizations/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"organizations/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"organizations/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"organizations/([^/]+)/embed/?$";s:45:"index.php?organization=$matches[1]&embed=true";s:34:"organizations/([^/]+)/trackback/?$";s:39:"index.php?organization=$matches[1]&tb=1";s:54:"organizations/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?organization=$matches[1]&feed=$matches[2]";s:49:"organizations/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?organization=$matches[1]&feed=$matches[2]";s:42:"organizations/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?organization=$matches[1]&paged=$matches[2]";s:49:"organizations/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?organization=$matches[1]&cpage=$matches[2]";s:38:"organizations/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?organization=$matches[1]&page=$matches[2]";s:30:"organizations/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"organizations/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"organizations/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"organizations/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"organizations/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"organizations/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:16:".*wp-signup.php$";s:21:"index.php?signup=true";s:18:".*wp-activate.php$";s:23:"index.php?activate=true";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=84&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'js-school-wp', 'yes'),
(41, 'stylesheet', 'js-school-wp', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '0', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:2:{s:41:"debug-bar-rewrite-rules/rewrite-rules.php";s:17:"umdbrr_deactivate";s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '8', 'yes'),
(82, 'page_on_front', '84', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1684760019', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:10:"copy_posts";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:10:"copy_posts";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:39:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:10:"copy_posts";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:10:"copy_posts";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:8:{i:1671101629;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1671108829;a:6:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1671108862;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1671108865;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1671110358;a:1:{s:21:"update_network_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1671111567;a:1:{s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1671177203;a:1:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'nonce_key', 'kjXDyI>lly&--S|eI7KNHr@uLbtiTOh[l41i&.@JKobZ le9sE$c~<=j0Ja)Q{hs', 'no'),
(116, 'nonce_salt', ':vbVa{c3%]qzovtOlp.57cs;`(DurlU7<tib03je$=&/gXe`7/Xf3#k2NXpb_B:6', 'no'),
(117, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(121, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(123, 'secure_auth_key', '~I7u9iA(TJMn],Jo60EaXX?3phjHtA[VgU5WGQ^UvNNIeo!Kc.T4c4m3HTfE+^]z', 'no'),
(124, 'secure_auth_salt', '_Wz{K<wY Uf7 a *&kt<WVdchJO>2XWM?4?+kx%3C!}.Y+bUQ&tS?7Ut@vk%h;m.', 'no'),
(125, 'logged_in_key', '4K_4 c$O9}(KaS~^D>&8;U-BQ,;j[zU?h/9S*M9E|d[n3jFQ*{9&c(UckQc|?=AV', 'no'),
(126, 'logged_in_salt', '>q0]D`lW^S_LVB@(G:;@-S#c&As{P5zeD_`0D1%_NUndDPI,hr#5/[uf3PxB;TV{', 'no'),
(138, 'can_compress_scripts', '1', 'no'),
(149, 'recovery_keys', 'a:0:{}', 'yes'),
(150, 'theme_mods_twentytwentythree', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1669279224;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(151, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(153, 'finished_updating_comment_type', '1', 'yes'),
(159, 'auth_key', 'Dv!^N)]-7@O}c5F8=t[,<(M~;Kay!]72j/kIRet]1[{ny7Xo)|F!}L)FRu7!E^6m', 'no'),
(160, 'auth_salt', '.~`W]8bc.N}x/?KN%$r+6`SD9|.8caix A2}XdhL)rQ{GL)QQX3~}%Z{t;~k%ea`', 'no'),
(161, 'theme_mods_js-school', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1669279219;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(162, 'current_theme', 'JS School WP', 'yes'),
(163, 'theme_switched', '', 'yes'),
(164, 'category_children', 'a:0:{}', 'yes'),
(183, 'recently_activated', 'a:11:{s:34:"advanced-custom-fields-pro/acf.php";i:1670850846;s:33:"classic-editor/classic-editor.php";i:1670850846;s:23:"debug-bar/debug-bar.php";i:1670850846;s:74:"debug-bar-actions-and-filters-addon/debug-bar-action-and-filters-addon.php";i:1670850846;s:41:"debug-bar-rewrite-rules/rewrite-rules.php";i:1670850846;s:31:"query-monitor/query-monitor.php";i:1670850846;s:27:"svg-support/svg-support.php";i:1670850846;s:27:"wp-crontrol/wp-crontrol.php";i:1670850846;s:31:"wp-migrate-db/wp-migrate-db.php";i:1670850846;s:33:"duplicate-post/duplicate-post.php";i:1670850846;s:24:"wordpress-seo/wp-seo.php";i:1670850846;}', 'yes'),
(185, 'bodhi_svgs_plugin_version', '2.5.3', 'yes'),
(186, 'bodhi_svgs_settings', 'a:4:{s:22:"sanitize_svg_front_end";s:2:"on";s:8:"restrict";a:1:{i:0;s:13:"administrator";}s:12:"sanitize_svg";s:2:"on";s:24:"sanitize_on_upload_roles";a:2:{i:0;s:13:"administrator";i:1;s:6:"editor";}}', 'yes'),
(187, 'yoast_migrations_free', 'a:1:{s:7:"version";s:5:"19.10";}', 'yes'),
(193, 'duplicate_post_show_notice', '', 'no'),
(194, 'duplicate_post_copytitle', '1', 'yes'),
(195, 'duplicate_post_copydate', '', 'yes'),
(196, 'duplicate_post_copystatus', '', 'yes'),
(197, 'duplicate_post_copyslug', '', 'yes'),
(198, 'duplicate_post_copyexcerpt', '1', 'yes'),
(199, 'duplicate_post_copycontent', '1', 'yes'),
(200, 'duplicate_post_copythumbnail', '1', 'yes'),
(201, 'duplicate_post_copytemplate', '1', 'yes'),
(202, 'duplicate_post_copyformat', '1', 'yes'),
(203, 'duplicate_post_copyauthor', '', 'yes'),
(204, 'duplicate_post_copypassword', '', 'yes'),
(205, 'duplicate_post_copyattachments', '', 'yes'),
(206, 'duplicate_post_copychildren', '', 'yes'),
(207, 'duplicate_post_copycomments', '', 'yes'),
(208, 'duplicate_post_copymenuorder', '1', 'yes'),
(209, 'duplicate_post_taxonomies_blacklist', '', 'yes'),
(210, 'duplicate_post_blacklist', '', 'yes'),
(211, 'duplicate_post_types_enabled', 'a:3:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:11:"team-member";}', 'yes'),
(212, 'duplicate_post_show_original_column', '', 'yes'),
(213, 'duplicate_post_show_original_in_post_states', '', 'yes'),
(214, 'duplicate_post_show_original_meta_box', '', 'yes'),
(215, 'duplicate_post_show_link', 'a:3:{s:9:"new_draft";s:1:"1";s:5:"clone";s:1:"1";s:17:"rewrite_republish";s:1:"1";}', 'yes'),
(216, 'duplicate_post_show_link_in', 'a:4:{s:3:"row";s:1:"1";s:8:"adminbar";s:1:"1";s:9:"submitbox";s:1:"1";s:11:"bulkactions";s:1:"1";}', 'yes'),
(217, 'duplicate_post_version', '4.5', 'yes'),
(258, 'acf_version', '6.0.5', 'yes'),
(261, 'classic-editor-replace', 'classic', 'yes'),
(262, 'classic-editor-allow-users', 'allow', 'yes'),
(301, 'theme_mods_js-school-wp', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(348, 'duplicate_post_title_prefix', '', 'yes'),
(349, 'duplicate_post_title_suffix', '', 'yes'),
(350, 'duplicate_post_increase_menu_order_by', '', 'yes'),
(351, 'duplicate_post_roles', 'a:4:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:13:"wpseo_manager";i:3;s:12:"wpseo_editor";}', 'yes'),
(512, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(653, 'wpseo_taxonomy_meta', 'a:1:{s:8:"post_tag";a:4:{i:8;a:3:{s:13:"wpseo_focuskw";s:3:"var";s:13:"wpseo_linkdex";s:2:"39";s:19:"wpseo_content_score";s:2:"90";}i:7;a:3:{s:13:"wpseo_focuskw";s:3:"let";s:13:"wpseo_linkdex";s:2:"32";s:19:"wpseo_content_score";s:2:"90";}i:5;a:3:{s:13:"wpseo_focuskw";s:8:"function";s:13:"wpseo_linkdex";s:2:"50";s:19:"wpseo_content_score";s:2:"90";}i:6;a:3:{s:13:"wpseo_focuskw";s:9:"variables";s:13:"wpseo_linkdex";s:2:"39";s:19:"wpseo_content_score";s:2:"90";}}}', 'yes'),
(829, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1670850274;}', 'no'),
(830, 'debug_bar_rewrite_rules_filters_list', 'a:3:{s:4:"list";a:13:{i:0;s:22:"category_rewrite_rules";i:1;s:25:"post_format_rewrite_rules";i:2;s:25:"team-member_rewrite_rules";i:3;s:26:"organization_rewrite_rules";i:4;s:18:"post_rewrite_rules";i:5;s:18:"date_rewrite_rules";i:6;s:18:"root_rewrite_rules";i:7;s:22:"comments_rewrite_rules";i:8;s:20:"search_rewrite_rules";i:9;s:20:"author_rewrite_rules";i:10;s:18:"page_rewrite_rules";i:11;s:17:"tag_rewrite_rules";i:12;s:19:"rewrite_rules_array";}s:5:"count";i:0;s:7:"details";a:0:{}}', 'yes'),
(832, 'debug_bar_rewrite_rules_installed', '1', 'yes'),
(833, 'wpseo', 'a:97:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:1;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:26:"permalink_settings_changed";s:29:"indexables_indexing_completed";b:1;s:13:"index_now_key";s:0:"";s:7:"version";s:5:"19.10";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:22:"show_onboarding_notice";b:0;s:18:"first_activated_on";b:0;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:36:"/%year%/%monthnum%/%day%/%postname%/";s:8:"home_url";s:25:"https://js-school-wp.test";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:0;s:34:"dismiss_premium_deactivated_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:0;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:28:"wordproof_integration_active";b:0;s:29:"wordproof_integration_changed";b:0;s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1670852378;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";}', 'yes'),
(834, 'wpseo_titles', 'a:145:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:17:"title-team-member";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:20:"metadesc-team-member";s:0:"";s:19:"noindex-team-member";b:0;s:30:"display-metabox-pt-team-member";b:1;s:30:"post_types-team-member-maintax";i:0;s:28:"schema-page-type-team-member";s:7:"WebPage";s:31:"schema-article-type-team-member";s:4:"None";s:24:"social-title-team-member";s:9:"%%title%%";s:30:"social-description-team-member";s:0:"";s:28:"social-image-url-team-member";s:0:"";s:27:"social-image-id-team-member";i:0;s:27:"title-ptarchive-team-member";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:30:"metadesc-ptarchive-team-member";s:0:"";s:29:"bctitle-ptarchive-team-member";s:0:"";s:29:"noindex-ptarchive-team-member";b:0;s:34:"social-title-ptarchive-team-member";s:21:"%%pt_plural%% Archive";s:40:"social-description-ptarchive-team-member";s:0:"";s:38:"social-image-url-ptarchive-team-member";s:0:"";s:37:"social-image-id-ptarchive-team-member";i:0;s:18:"title-organization";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-organization";s:0:"";s:20:"noindex-organization";b:0;s:31:"display-metabox-pt-organization";b:1;s:31:"post_types-organization-maintax";i:0;s:29:"schema-page-type-organization";s:7:"WebPage";s:32:"schema-article-type-organization";s:4:"None";s:25:"social-title-organization";s:9:"%%title%%";s:31:"social-description-organization";s:0:"";s:29:"social-image-url-organization";s:0:"";s:28:"social-image-id-organization";i:0;s:28:"title-ptarchive-organization";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:31:"metadesc-ptarchive-organization";s:0:"";s:30:"bctitle-ptarchive-organization";s:0:"";s:30:"noindex-ptarchive-organization";b:0;s:35:"social-title-ptarchive-organization";s:21:"%%pt_plural%% Archive";s:41:"social-description-ptarchive-organization";s:0:"";s:39:"social-image-url-ptarchive-organization";s:0:"";s:38:"social-image-id-ptarchive-organization";i:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'yes'),
(835, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'yes'),
(935, 'WPLANG', '', 'yes'),
(936, 'new_admin_email', 'anamarija.papic@agilo.co', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=694 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(6, 6, 'classic-editor-remember', 'classic-editor'),
(7, 6, '_edit_last', '1'),
(8, 6, '_edit_lock', '1669278041:1'),
(9, 6, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(10, 6, '_yoast_wpseo_wordproof_timestamp', ''),
(11, 6, 'inline_featured_image', '0'),
(12, 8, 'classic-editor-remember', 'classic-editor'),
(13, 8, '_edit_last', '1'),
(14, 8, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(15, 8, '_yoast_wpseo_wordproof_timestamp', ''),
(16, 8, 'inline_featured_image', '0'),
(17, 8, '_edit_lock', '1669277929:1'),
(18, 10, 'classic-editor-remember', 'classic-editor'),
(19, 10, '_edit_last', '1'),
(20, 10, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(21, 10, '_yoast_wpseo_wordproof_timestamp', ''),
(22, 10, 'inline_featured_image', '0'),
(23, 10, '_edit_lock', '1669277939:1'),
(28, 14, '_edit_last', '1'),
(29, 14, '_edit_lock', '1669730193:1'),
(30, 17, 'classic-editor-remember', 'classic-editor'),
(31, 17, '_edit_last', '1'),
(32, 17, '_edit_lock', '1669288981:1'),
(33, 18, '_wp_attached_file', '2022/11/01.png'),
(34, 18, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:504;s:6:"height";i:508;s:4:"file";s:14:"2022/11/01.png";s:8:"filesize";i:599289;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"01-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:194479;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"01-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:56585;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(35, 17, 'js_school_wp_team_member_settings_position', 'President'),
(36, 17, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(37, 17, 'js_school_wp_team_member_settings_photo', '18'),
(38, 17, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(39, 17, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(40, 17, '_yoast_wpseo_wordproof_timestamp', ''),
(41, 19, 'classic-editor-remember', 'classic-editor'),
(42, 19, '_edit_last', '1'),
(43, 19, '_edit_lock', '1669289027:1'),
(44, 20, '_wp_attached_file', '2022/11/02.png'),
(45, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:506;s:4:"file";s:14:"2022/11/02.png";s:8:"filesize";i:484406;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"02-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:141400;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41442;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(46, 19, 'js_school_wp_team_member_settings_position', 'SVP Finance & Administration'),
(47, 19, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(48, 19, 'js_school_wp_team_member_settings_photo', '20'),
(49, 19, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(50, 19, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(51, 19, '_yoast_wpseo_wordproof_timestamp', ''),
(52, 21, 'classic-editor-remember', 'classic-editor'),
(53, 21, '_edit_last', '1'),
(54, 21, '_edit_lock', '1669289079:1'),
(55, 22, '_wp_attached_file', '2022/11/03.png'),
(56, 22, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:510;s:6:"height";i:510;s:4:"file";s:14:"2022/11/03.png";s:8:"filesize";i:497435;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"03-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:155507;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"03-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46224;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(57, 21, 'js_school_wp_team_member_settings_position', 'President. STEM Learning'),
(58, 21, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(59, 21, 'js_school_wp_team_member_settings_photo', '22'),
(60, 21, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(61, 21, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(62, 21, '_yoast_wpseo_wordproof_timestamp', ''),
(63, 23, 'classic-editor-remember', 'classic-editor'),
(64, 24, '_wp_attached_file', '2022/11/04.png'),
(65, 24, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:508;s:6:"height";i:508;s:4:"file";s:14:"2022/11/04.png";s:8:"filesize";i:484120;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"04-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:146221;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"04-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:40241;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(66, 23, '_edit_last', '1'),
(67, 23, 'js_school_wp_team_member_settings_position', 'General Manager, Late Nite Labs'),
(68, 23, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(69, 23, 'js_school_wp_team_member_settings_photo', '24'),
(70, 23, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(71, 23, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(72, 23, '_yoast_wpseo_wordproof_timestamp', ''),
(73, 23, '_edit_lock', '1669289129:1'),
(74, 25, 'classic-editor-remember', 'classic-editor'),
(75, 25, '_edit_last', '1'),
(76, 25, '_edit_lock', '1669289168:1'),
(77, 26, '_wp_attached_file', '2022/11/05.png'),
(78, 26, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:510;s:4:"file";s:14:"2022/11/05.png";s:8:"filesize";i:432941;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"05-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:120819;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"05-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:34877;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(79, 25, 'js_school_wp_team_member_settings_position', 'General Manager, prepU'),
(80, 25, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(81, 25, 'js_school_wp_team_member_settings_photo', '26'),
(82, 25, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(83, 25, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(84, 25, '_yoast_wpseo_wordproof_timestamp', ''),
(85, 27, 'classic-editor-remember', 'classic-editor'),
(86, 27, '_edit_last', '1'),
(87, 27, '_edit_lock', '1669289227:1'),
(88, 28, '_wp_attached_file', '2022/11/06.png'),
(89, 28, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:508;s:6:"height";i:512;s:4:"file";s:14:"2022/11/06.png";s:8:"filesize";i:561990;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"06-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:175340;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"06-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:51605;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 27, 'js_school_wp_team_member_settings_position', 'General Manager, Nature Education'),
(91, 27, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(92, 27, 'js_school_wp_team_member_settings_photo', '28'),
(93, 27, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(94, 27, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(95, 27, '_yoast_wpseo_wordproof_timestamp', ''),
(96, 29, 'classic-editor-remember', 'classic-editor'),
(97, 29, '_edit_last', '1'),
(98, 29, '_edit_lock', '1669289271:1'),
(99, 30, '_wp_attached_file', '2022/11/07.png'),
(100, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:502;s:6:"height";i:506;s:4:"file";s:14:"2022/11/07.png";s:8:"filesize";i:434957;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"07-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:126980;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"07-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:38488;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(101, 29, 'js_school_wp_team_member_settings_position', 'President, i>clicker'),
(102, 29, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(103, 29, 'js_school_wp_team_member_settings_photo', '30'),
(104, 29, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(105, 29, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(106, 29, '_yoast_wpseo_wordproof_timestamp', ''),
(107, 31, 'classic-editor-remember', 'classic-editor'),
(108, 32, '_wp_attached_file', '2022/11/08.png'),
(109, 32, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:506;s:4:"file";s:14:"2022/11/08.png";s:8:"filesize";i:450844;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"08-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:143061;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"08-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:40632;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(110, 31, '_edit_last', '1'),
(111, 31, 'js_school_wp_team_member_settings_position', 'President, Skyfactor'),
(112, 31, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(113, 31, 'js_school_wp_team_member_settings_photo', '32'),
(114, 31, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(115, 31, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(116, 31, '_yoast_wpseo_wordproof_timestamp', ''),
(117, 31, '_edit_lock', '1669289312:1'),
(118, 33, 'classic-editor-remember', 'classic-editor'),
(119, 33, '_edit_last', '1'),
(120, 33, '_edit_lock', '1669641487:1'),
(121, 34, '_wp_attached_file', '2022/11/09.png'),
(122, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:506;s:4:"file";s:14:"2022/11/09.png";s:8:"filesize";i:452727;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"09-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:132354;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"09-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36331;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(123, 33, 'js_school_wp_team_member_settings_position', 'President, Hayden-McNeil'),
(124, 33, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(125, 33, 'js_school_wp_team_member_settings_photo', '34'),
(126, 33, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(127, 33, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(128, 33, '_yoast_wpseo_wordproof_timestamp', ''),
(129, 35, 'classic-editor-remember', 'classic-editor'),
(130, 35, '_edit_last', '1'),
(131, 35, '_edit_lock', '1669289551:1'),
(132, 36, '_wp_attached_file', '2022/11/10.png'),
(133, 36, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:508;s:6:"height";i:512;s:4:"file";s:14:"2022/11/10.png";s:8:"filesize";i:522991;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"10-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:160680;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"10-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:47418;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(134, 35, 'js_school_wp_team_member_settings_position', 'VP, Products'),
(135, 35, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(136, 35, 'js_school_wp_team_member_settings_photo', '36'),
(137, 35, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(138, 35, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(139, 35, '_yoast_wpseo_wordproof_timestamp', ''),
(140, 37, 'classic-editor-remember', 'classic-editor'),
(141, 38, '_wp_attached_file', '2022/11/11.png'),
(142, 38, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:508;s:6:"height";i:508;s:4:"file";s:14:"2022/11/11.png";s:8:"filesize";i:437265;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"11-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:125973;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"11-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37386;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(143, 37, '_edit_last', '1'),
(144, 37, 'js_school_wp_team_member_settings_position', 'Head of Technology'),
(145, 37, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(146, 37, 'js_school_wp_team_member_settings_photo', '38'),
(147, 37, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(148, 37, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(149, 37, '_yoast_wpseo_wordproof_timestamp', ''),
(150, 37, '_edit_lock', '1669289447:1'),
(151, 39, 'classic-editor-remember', 'classic-editor'),
(152, 39, '_edit_last', '1'),
(153, 39, '_edit_lock', '1669289484:1'),
(154, 40, '_wp_attached_file', '2022/11/12.png'),
(155, 40, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:510;s:4:"file";s:14:"2022/11/12.png";s:8:"filesize";i:406698;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"12-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:111664;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"12-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29758;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(156, 39, 'js_school_wp_team_member_settings_position', 'Head or Marketing'),
(157, 39, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(158, 39, 'js_school_wp_team_member_settings_photo', '40'),
(159, 39, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(160, 39, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(161, 39, '_yoast_wpseo_wordproof_timestamp', ''),
(162, 41, 'classic-editor-remember', 'classic-editor'),
(163, 42, '_wp_attached_file', '2022/11/13.png'),
(164, 42, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:504;s:6:"height";i:506;s:4:"file";s:14:"2022/11/13.png";s:8:"filesize";i:444449;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"13-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:131015;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"13-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:38243;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(165, 41, '_edit_last', '1'),
(166, 41, 'js_school_wp_team_member_settings_position', 'Director of Sales'),
(167, 41, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(168, 41, 'js_school_wp_team_member_settings_photo', '42'),
(169, 41, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(170, 41, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(171, 41, '_yoast_wpseo_wordproof_timestamp', ''),
(172, 41, '_edit_lock', '1669289512:1'),
(173, 43, 'classic-editor-remember', 'classic-editor'),
(174, 43, '_edit_last', '1'),
(175, 43, '_edit_lock', '1669289548:1'),
(176, 44, '_wp_attached_file', '2022/11/14.png'),
(177, 44, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:506;s:6:"height";i:510;s:4:"file";s:14:"2022/11/14.png";s:8:"filesize";i:445784;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"14-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:130107;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"14-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36980;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(178, 43, 'js_school_wp_team_member_settings_position', 'SVP Sales'),
(179, 43, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(180, 43, 'js_school_wp_team_member_settings_photo', '44'),
(181, 43, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(182, 43, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(183, 43, '_yoast_wpseo_wordproof_timestamp', ''),
(184, 45, 'classic-editor-remember', 'classic-editor'),
(185, 46, '_wp_attached_file', '2022/11/15.png'),
(186, 46, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:508;s:6:"height";i:508;s:4:"file";s:14:"2022/11/15.png";s:8:"filesize";i:530799;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:14:"15-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:168203;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"15-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:50320;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(187, 45, '_edit_last', '1'),
(188, 45, 'js_school_wp_team_member_settings_position', 'Director of Strategic Initiatives'),
(189, 45, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(190, 45, 'js_school_wp_team_member_settings_photo', '46'),
(191, 45, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(192, 45, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(193, 45, '_yoast_wpseo_wordproof_timestamp', ''),
(194, 45, '_edit_lock', '1669289598:1'),
(217, 49, 'classic-editor-remember', 'classic-editor'),
(218, 49, 'js_school_wp_team_member_settings_position', 'Director of Strategic Initiatives'),
(219, 49, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(220, 49, 'js_school_wp_team_member_settings_photo', '46'),
(221, 49, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(222, 49, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(223, 49, '_yoast_wpseo_wordproof_timestamp', ''),
(224, 49, '_dp_original', '45'),
(225, 50, 'classic-editor-remember', 'classic-editor'),
(226, 50, 'js_school_wp_team_member_settings_position', 'SVP Sales'),
(227, 50, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(228, 50, 'js_school_wp_team_member_settings_photo', '44'),
(229, 50, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(230, 50, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(231, 50, '_yoast_wpseo_wordproof_timestamp', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(232, 50, '_dp_original', '43'),
(233, 51, 'classic-editor-remember', 'classic-editor'),
(234, 51, 'js_school_wp_team_member_settings_position', 'Director of Sales'),
(235, 51, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(236, 51, 'js_school_wp_team_member_settings_photo', '42'),
(237, 51, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(238, 51, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(239, 51, '_yoast_wpseo_wordproof_timestamp', ''),
(240, 51, '_dp_original', '41'),
(241, 52, 'classic-editor-remember', 'classic-editor'),
(242, 52, 'js_school_wp_team_member_settings_position', 'Head or Marketing'),
(243, 52, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(244, 52, 'js_school_wp_team_member_settings_photo', '40'),
(245, 52, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(246, 52, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(247, 52, '_yoast_wpseo_wordproof_timestamp', ''),
(248, 52, '_dp_original', '39'),
(249, 53, 'classic-editor-remember', 'classic-editor'),
(250, 53, 'js_school_wp_team_member_settings_position', 'Head of Technology'),
(251, 53, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(252, 53, 'js_school_wp_team_member_settings_photo', '38'),
(253, 53, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(254, 53, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(255, 53, '_yoast_wpseo_wordproof_timestamp', ''),
(256, 53, '_dp_original', '37'),
(257, 54, 'classic-editor-remember', 'classic-editor'),
(258, 54, 'js_school_wp_team_member_settings_position', 'VP, Products'),
(259, 54, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(260, 54, 'js_school_wp_team_member_settings_photo', '36'),
(261, 54, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(262, 54, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(263, 54, '_yoast_wpseo_wordproof_timestamp', ''),
(264, 54, '_dp_original', '35'),
(265, 55, 'classic-editor-remember', 'classic-editor'),
(266, 55, 'js_school_wp_team_member_settings_position', 'President, Hayden-McNeil'),
(267, 55, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(268, 55, 'js_school_wp_team_member_settings_photo', '34'),
(269, 55, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(270, 55, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(271, 55, '_yoast_wpseo_wordproof_timestamp', ''),
(272, 55, '_dp_original', '33'),
(273, 56, 'classic-editor-remember', 'classic-editor'),
(274, 56, 'js_school_wp_team_member_settings_position', 'President, Skyfactor'),
(275, 56, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(276, 56, 'js_school_wp_team_member_settings_photo', '32'),
(277, 56, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(278, 56, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(279, 56, '_yoast_wpseo_wordproof_timestamp', ''),
(280, 56, '_dp_original', '31'),
(281, 57, 'classic-editor-remember', 'classic-editor'),
(282, 57, 'js_school_wp_team_member_settings_position', 'President, i>clicker'),
(283, 57, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(284, 57, 'js_school_wp_team_member_settings_photo', '30'),
(285, 57, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(286, 57, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(287, 57, '_yoast_wpseo_wordproof_timestamp', ''),
(288, 57, '_dp_original', '29'),
(289, 58, 'classic-editor-remember', 'classic-editor'),
(290, 58, 'js_school_wp_team_member_settings_position', 'General Manager, Nature Education'),
(291, 58, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(292, 58, 'js_school_wp_team_member_settings_photo', '28'),
(293, 58, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(294, 58, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(295, 58, '_yoast_wpseo_wordproof_timestamp', ''),
(296, 58, '_dp_original', '27'),
(297, 59, 'classic-editor-remember', 'classic-editor'),
(298, 59, 'js_school_wp_team_member_settings_position', 'General Manager, prepU'),
(299, 59, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(300, 59, 'js_school_wp_team_member_settings_photo', '26'),
(301, 59, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(302, 59, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(303, 59, '_yoast_wpseo_wordproof_timestamp', ''),
(304, 59, '_dp_original', '25'),
(305, 60, 'classic-editor-remember', 'classic-editor'),
(306, 60, 'js_school_wp_team_member_settings_position', 'General Manager, Late Nite Labs'),
(307, 60, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(308, 60, 'js_school_wp_team_member_settings_photo', '24'),
(309, 60, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(310, 60, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(311, 60, '_yoast_wpseo_wordproof_timestamp', ''),
(312, 60, '_dp_original', '23'),
(313, 61, 'classic-editor-remember', 'classic-editor'),
(314, 61, 'js_school_wp_team_member_settings_position', 'President. STEM Learning'),
(315, 61, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(316, 61, 'js_school_wp_team_member_settings_photo', '22'),
(317, 61, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(318, 61, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(319, 61, '_yoast_wpseo_wordproof_timestamp', ''),
(320, 61, '_dp_original', '21'),
(321, 62, 'classic-editor-remember', 'classic-editor'),
(322, 62, 'js_school_wp_team_member_settings_position', 'SVP Finance & Administration'),
(323, 62, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(324, 62, 'js_school_wp_team_member_settings_photo', '20'),
(325, 62, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(326, 62, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(327, 62, '_yoast_wpseo_wordproof_timestamp', ''),
(328, 62, '_dp_original', '19'),
(329, 63, 'classic-editor-remember', 'classic-editor'),
(330, 63, 'js_school_wp_team_member_settings_position', 'President'),
(331, 63, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(332, 63, 'js_school_wp_team_member_settings_photo', '18'),
(333, 63, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(334, 63, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(335, 63, '_yoast_wpseo_wordproof_timestamp', ''),
(336, 63, '_dp_original', '17'),
(337, 64, 'classic-editor-remember', 'classic-editor'),
(338, 64, 'js_school_wp_team_member_settings_position', 'Director of Strategic Initiatives'),
(339, 64, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(340, 64, 'js_school_wp_team_member_settings_photo', '46'),
(341, 64, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(342, 64, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(343, 64, '_yoast_wpseo_wordproof_timestamp', ''),
(345, 64, '_dp_original', '49'),
(346, 65, 'classic-editor-remember', 'classic-editor'),
(347, 65, 'js_school_wp_team_member_settings_position', 'President'),
(348, 65, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(349, 65, 'js_school_wp_team_member_settings_photo', '18'),
(350, 65, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(351, 65, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(352, 65, '_yoast_wpseo_wordproof_timestamp', ''),
(354, 65, '_dp_original', '63'),
(355, 66, 'classic-editor-remember', 'classic-editor'),
(356, 66, 'js_school_wp_team_member_settings_position', 'SVP Finance & Administration'),
(357, 66, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(358, 66, 'js_school_wp_team_member_settings_photo', '20'),
(359, 66, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(360, 66, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(361, 66, '_yoast_wpseo_wordproof_timestamp', ''),
(363, 66, '_dp_original', '62'),
(364, 67, 'classic-editor-remember', 'classic-editor'),
(365, 67, 'js_school_wp_team_member_settings_position', 'President. STEM Learning'),
(366, 67, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(367, 67, 'js_school_wp_team_member_settings_photo', '22'),
(368, 67, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(369, 67, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(370, 67, '_yoast_wpseo_wordproof_timestamp', ''),
(372, 67, '_dp_original', '61'),
(373, 68, 'classic-editor-remember', 'classic-editor'),
(374, 68, 'js_school_wp_team_member_settings_position', 'General Manager, Late Nite Labs'),
(375, 68, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(376, 68, 'js_school_wp_team_member_settings_photo', '24'),
(377, 68, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(378, 68, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(379, 68, '_yoast_wpseo_wordproof_timestamp', ''),
(381, 68, '_dp_original', '60'),
(382, 69, 'classic-editor-remember', 'classic-editor'),
(383, 69, 'js_school_wp_team_member_settings_position', 'General Manager, prepU'),
(384, 69, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(385, 69, 'js_school_wp_team_member_settings_photo', '26'),
(386, 69, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(387, 69, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(388, 69, '_yoast_wpseo_wordproof_timestamp', ''),
(390, 69, '_dp_original', '59'),
(391, 70, 'classic-editor-remember', 'classic-editor'),
(392, 70, 'js_school_wp_team_member_settings_position', 'General Manager, Nature Education'),
(393, 70, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(394, 70, 'js_school_wp_team_member_settings_photo', '28'),
(395, 70, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(396, 70, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(397, 70, '_yoast_wpseo_wordproof_timestamp', ''),
(399, 70, '_dp_original', '58'),
(400, 71, 'classic-editor-remember', 'classic-editor'),
(401, 71, 'js_school_wp_team_member_settings_position', 'President, i>clicker'),
(402, 71, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(403, 71, 'js_school_wp_team_member_settings_photo', '30'),
(404, 71, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(405, 71, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(406, 71, '_yoast_wpseo_wordproof_timestamp', ''),
(408, 71, '_dp_original', '57'),
(409, 72, 'classic-editor-remember', 'classic-editor'),
(410, 72, 'js_school_wp_team_member_settings_position', 'President, Skyfactor'),
(411, 72, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(412, 72, 'js_school_wp_team_member_settings_photo', '32'),
(413, 72, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(414, 72, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(415, 72, '_yoast_wpseo_wordproof_timestamp', ''),
(417, 72, '_dp_original', '56'),
(418, 73, 'classic-editor-remember', 'classic-editor'),
(419, 73, 'js_school_wp_team_member_settings_position', 'SVP Sales'),
(420, 73, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(421, 73, 'js_school_wp_team_member_settings_photo', '44'),
(422, 73, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(423, 73, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(424, 73, '_yoast_wpseo_wordproof_timestamp', ''),
(426, 73, '_dp_original', '50'),
(427, 74, 'classic-editor-remember', 'classic-editor'),
(428, 74, 'js_school_wp_team_member_settings_position', 'Director of Sales'),
(429, 74, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(430, 74, 'js_school_wp_team_member_settings_photo', '42'),
(431, 74, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(432, 74, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(433, 74, '_yoast_wpseo_wordproof_timestamp', ''),
(435, 74, '_dp_original', '51'),
(436, 75, 'classic-editor-remember', 'classic-editor'),
(437, 75, 'js_school_wp_team_member_settings_position', 'Head or Marketing'),
(438, 75, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(439, 75, 'js_school_wp_team_member_settings_photo', '40'),
(440, 75, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(441, 75, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(442, 75, '_yoast_wpseo_wordproof_timestamp', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(444, 75, '_dp_original', '52'),
(445, 76, 'classic-editor-remember', 'classic-editor'),
(446, 76, 'js_school_wp_team_member_settings_position', 'Head of Technology'),
(447, 76, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(448, 76, 'js_school_wp_team_member_settings_photo', '38'),
(449, 76, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(450, 76, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(451, 76, '_yoast_wpseo_wordproof_timestamp', ''),
(453, 76, '_dp_original', '53'),
(454, 77, 'classic-editor-remember', 'classic-editor'),
(455, 77, 'js_school_wp_team_member_settings_position', 'VP, Products'),
(456, 77, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(457, 77, 'js_school_wp_team_member_settings_photo', '36'),
(458, 77, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(459, 77, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(460, 77, '_yoast_wpseo_wordproof_timestamp', ''),
(462, 77, '_dp_original', '54'),
(463, 78, 'classic-editor-remember', 'classic-editor'),
(464, 78, 'js_school_wp_team_member_settings_position', 'President, Hayden-McNeil'),
(465, 78, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(466, 78, 'js_school_wp_team_member_settings_photo', '34'),
(467, 78, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(468, 78, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(469, 78, '_yoast_wpseo_wordproof_timestamp', ''),
(471, 78, '_dp_original', '55'),
(472, 79, 'classic-editor-remember', 'classic-editor'),
(473, 79, 'js_school_wp_team_member_settings_position', 'Director of Strategic Initiatives'),
(474, 79, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(475, 79, 'js_school_wp_team_member_settings_photo', '46'),
(476, 79, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(477, 79, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(478, 79, '_yoast_wpseo_wordproof_timestamp', ''),
(479, 79, '_dp_original', '45'),
(480, 80, 'classic-editor-remember', 'classic-editor'),
(481, 80, 'js_school_wp_team_member_settings_position', 'SVP Sales'),
(482, 80, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(483, 80, 'js_school_wp_team_member_settings_photo', '44'),
(484, 80, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(485, 80, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(486, 80, '_yoast_wpseo_wordproof_timestamp', ''),
(487, 80, '_dp_original', '43'),
(488, 81, 'classic-editor-remember', 'classic-editor'),
(489, 81, 'js_school_wp_team_member_settings_position', 'Director of Sales'),
(490, 81, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(491, 81, 'js_school_wp_team_member_settings_photo', '42'),
(492, 81, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(493, 81, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(494, 81, '_yoast_wpseo_wordproof_timestamp', ''),
(495, 81, '_dp_original', '41'),
(496, 82, 'classic-editor-remember', 'classic-editor'),
(497, 82, 'js_school_wp_team_member_settings_position', 'Head or Marketing'),
(498, 82, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(499, 82, 'js_school_wp_team_member_settings_photo', '40'),
(500, 82, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(501, 82, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(502, 82, '_yoast_wpseo_wordproof_timestamp', ''),
(503, 82, '_dp_original', '39'),
(504, 83, 'classic-editor-remember', 'classic-editor'),
(505, 83, 'js_school_wp_team_member_settings_position', 'Head of Technology'),
(506, 83, '_js_school_wp_team_member_settings_position', 'field_637f4f1aed9d8'),
(507, 83, 'js_school_wp_team_member_settings_photo', '38'),
(508, 83, '_js_school_wp_team_member_settings_photo', 'field_637f4fd2ed9d9'),
(509, 83, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(510, 83, '_yoast_wpseo_wordproof_timestamp', ''),
(511, 83, '_dp_original', '37'),
(512, 70, '_edit_last', '1'),
(513, 80, '_edit_last', '1'),
(514, 81, '_edit_last', '1'),
(515, 83, '_edit_last', '1'),
(516, 64, '_edit_last', '1'),
(517, 65, '_edit_last', '1'),
(518, 66, '_edit_last', '1'),
(519, 67, '_edit_last', '1'),
(520, 68, '_edit_last', '1'),
(521, 77, '_edit_last', '1'),
(522, 76, '_edit_last', '1'),
(523, 71, '_edit_last', '1'),
(524, 78, '_edit_last', '1'),
(525, 72, '_edit_last', '1'),
(526, 75, '_edit_last', '1'),
(527, 79, '_edit_last', '1'),
(528, 82, '_edit_last', '1'),
(529, 73, '_edit_last', '1'),
(530, 74, '_edit_last', '1'),
(531, 69, '_edit_last', '1'),
(532, 49, '_edit_last', '1'),
(533, 62, '_edit_last', '1'),
(534, 61, '_edit_last', '1'),
(535, 60, '_edit_last', '1'),
(536, 59, '_edit_last', '1'),
(537, 58, '_edit_last', '1'),
(538, 57, '_edit_last', '1'),
(539, 56, '_edit_last', '1'),
(540, 55, '_edit_last', '1'),
(541, 54, '_edit_last', '1'),
(542, 53, '_edit_last', '1'),
(543, 52, '_edit_last', '1'),
(544, 51, '_edit_last', '1'),
(545, 50, '_edit_last', '1'),
(546, 63, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(547, 84, 'classic-editor-remember', 'classic-editor'),
(548, 84, '_edit_last', '1'),
(549, 84, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(550, 84, '_yoast_wpseo_wordproof_timestamp', ''),
(551, 84, 'inline_featured_image', '0'),
(552, 84, '_edit_lock', '1671091909:1'),
(553, 55, '_edit_lock', '1669641448:1'),
(554, 78, '_edit_lock', '1669641474:1'),
(555, 86, '_edit_last', '1'),
(556, 86, '_edit_lock', '1669817884:1'),
(557, 88, 'classic-editor-remember', 'classic-editor'),
(558, 88, '_edit_last', '1'),
(559, 88, '_edit_lock', '1669709935:1'),
(561, 88, '_yoast_wpseo_content_score', '90'),
(562, 88, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(563, 88, '_yoast_wpseo_wordproof_timestamp', ''),
(564, 88, 'inline_featured_image', '0'),
(565, 91, 'classic-editor-remember', 'classic-editor'),
(566, 91, '_edit_last', '1'),
(567, 91, '_edit_lock', '1669901189:1'),
(569, 91, '_yoast_wpseo_content_score', '90'),
(570, 91, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(571, 91, '_yoast_wpseo_wordproof_timestamp', ''),
(572, 91, 'inline_featured_image', '0'),
(574, 94, 'classic-editor-remember', 'classic-editor'),
(575, 94, '_edit_last', '1'),
(577, 94, '_yoast_wpseo_content_score', '90'),
(578, 94, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(579, 94, '_yoast_wpseo_wordproof_timestamp', ''),
(580, 94, 'inline_featured_image', '0'),
(581, 94, '_edit_lock', '1669901150:1'),
(583, 50, '_edit_lock', '1669972488:1'),
(584, 96, 'classic-editor-remember', 'classic-editor'),
(585, 96, '_edit_last', '1'),
(586, 96, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(587, 96, '_yoast_wpseo_wordproof_timestamp', ''),
(588, 96, '_edit_lock', '1669980837:1'),
(589, 97, 'classic-editor-remember', 'classic-editor'),
(590, 97, '_edit_last', '1'),
(591, 97, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(592, 97, '_yoast_wpseo_wordproof_timestamp', ''),
(593, 97, '_edit_lock', '1669980853:1'),
(594, 98, 'classic-editor-remember', 'classic-editor'),
(595, 98, '_edit_last', '1'),
(596, 98, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(597, 98, '_yoast_wpseo_wordproof_timestamp', ''),
(598, 98, '_edit_lock', '1669980858:1'),
(599, 100, 'classic-editor-remember', 'classic-editor'),
(600, 100, '_edit_last', '1'),
(601, 100, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(602, 100, '_yoast_wpseo_wordproof_timestamp', ''),
(603, 100, '_edit_lock', '1669980876:1'),
(604, 101, 'classic-editor-remember', 'classic-editor'),
(605, 101, '_edit_last', '1'),
(606, 101, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(607, 101, '_yoast_wpseo_wordproof_timestamp', ''),
(608, 101, '_edit_lock', '1669980887:1'),
(609, 102, 'classic-editor-remember', 'classic-editor'),
(610, 102, '_edit_last', '1'),
(611, 102, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(612, 102, '_yoast_wpseo_wordproof_timestamp', ''),
(613, 102, '_edit_lock', '1669980906:1'),
(614, 103, 'classic-editor-remember', 'classic-editor'),
(615, 103, '_edit_last', '1'),
(616, 103, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(617, 103, '_yoast_wpseo_wordproof_timestamp', ''),
(618, 103, '_edit_lock', '1669980920:1'),
(619, 104, 'classic-editor-remember', 'classic-editor'),
(620, 104, '_edit_last', '1'),
(621, 104, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(622, 104, '_yoast_wpseo_wordproof_timestamp', ''),
(623, 104, '_edit_lock', '1669980924:1'),
(624, 105, 'classic-editor-remember', 'classic-editor'),
(625, 105, '_edit_last', '1'),
(626, 105, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(627, 105, '_yoast_wpseo_wordproof_timestamp', ''),
(628, 105, '_edit_lock', '1669980957:1'),
(629, 106, 'classic-editor-remember', 'classic-editor'),
(630, 106, '_edit_last', '1'),
(631, 106, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(632, 106, '_yoast_wpseo_wordproof_timestamp', ''),
(633, 106, '_edit_lock', '1669980972:1'),
(634, 107, 'classic-editor-remember', 'classic-editor'),
(635, 107, '_edit_last', '1'),
(636, 107, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(637, 107, '_yoast_wpseo_wordproof_timestamp', ''),
(638, 107, '_edit_lock', '1669980982:1'),
(639, 108, 'classic-editor-remember', 'classic-editor'),
(640, 108, '_edit_last', '1'),
(641, 108, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(642, 108, '_yoast_wpseo_wordproof_timestamp', ''),
(643, 108, '_edit_lock', '1669980998:1'),
(644, 109, 'classic-editor-remember', 'classic-editor'),
(645, 109, '_edit_last', '1'),
(646, 109, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(647, 109, '_yoast_wpseo_wordproof_timestamp', ''),
(648, 109, '_edit_lock', '1669981008:1'),
(649, 110, 'classic-editor-remember', 'classic-editor'),
(650, 110, '_edit_last', '1'),
(651, 110, '_yoast_wpseo_estimated-reading-time-minutes', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(652, 110, '_yoast_wpseo_wordproof_timestamp', ''),
(653, 110, '_edit_lock', '1669981016:1'),
(654, 111, 'classic-editor-remember', 'classic-editor'),
(655, 111, '_edit_last', '1'),
(656, 111, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(657, 111, '_yoast_wpseo_wordproof_timestamp', ''),
(658, 111, '_edit_lock', '1669981024:1'),
(660, 113, 'classic-editor-remember', 'classic-editor'),
(661, 113, '_edit_last', '1'),
(662, 113, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(663, 113, '_yoast_wpseo_wordproof_timestamp', ''),
(664, 113, '_edit_lock', '1669981161:1'),
(665, 114, 'classic-editor-remember', 'classic-editor'),
(666, 114, '_edit_last', '1'),
(667, 114, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(668, 114, '_yoast_wpseo_wordproof_timestamp', ''),
(669, 114, '_edit_lock', '1669981173:1'),
(670, 115, 'classic-editor-remember', 'classic-editor'),
(671, 115, '_edit_last', '1'),
(672, 115, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(673, 115, '_yoast_wpseo_wordproof_timestamp', ''),
(674, 115, '_edit_lock', '1669981191:1'),
(675, 116, 'classic-editor-remember', 'classic-editor'),
(676, 116, '_edit_last', '1'),
(677, 116, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(678, 116, '_yoast_wpseo_wordproof_timestamp', ''),
(679, 116, '_edit_lock', '1669981208:1'),
(680, 117, 'classic-editor-remember', 'classic-editor'),
(681, 117, '_edit_last', '1'),
(682, 117, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(683, 117, '_yoast_wpseo_wordproof_timestamp', ''),
(684, 117, '_edit_lock', '1670839702:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-11-23 12:53:39', '2022-11-23 12:53:39', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-11-23 12:53:39', '2022-11-23 12:53:39', '', 0, 'https://js-school-wp.test/?p=1', 0, 'post', '', 1),
(6, 1, '2022-11-24 08:20:40', '2022-11-24 08:20:40', '', 'Infinite scroll', '', 'publish', 'closed', 'closed', '', 'infinite-scroll', '', '', '2022-11-24 08:20:40', '2022-11-24 08:20:40', '', 0, 'https://js-school-wp.test/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-11-24 08:20:40', '2022-11-24 08:20:40', '', 'Infinite scroll', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-11-24 08:20:40', '2022-11-24 08:20:40', '', 6, 'https://js-school-wp.test/?p=7', 0, 'revision', '', 0),
(8, 1, '2022-11-24 08:20:55', '2022-11-24 08:20:55', '', 'Stackoverflow tags', '', 'publish', 'closed', 'closed', '', 'stackoverflow-tags', '', '', '2022-11-24 08:20:55', '2022-11-24 08:20:55', '', 0, 'https://js-school-wp.test/?page_id=8', 0, 'page', '', 0),
(9, 1, '2022-11-24 08:20:55', '2022-11-24 08:20:55', '', 'Stackoverflow tags', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-11-24 08:20:55', '2022-11-24 08:20:55', '', 8, 'https://js-school-wp.test/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-11-24 08:21:12', '2022-11-24 08:21:12', '', 'Autocomplete menu & CORS endpoint', '', 'publish', 'closed', 'closed', '', 'autocomplete-menu-cors-endpoint', '', '', '2022-11-24 08:21:12', '2022-11-24 08:21:12', '', 0, 'https://js-school-wp.test/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-11-24 08:21:12', '2022-11-24 08:21:12', '', 'Autocomplete menu & CORS endpoint', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-11-24 08:21:12', '2022-11-24 08:21:12', '', 10, 'https://js-school-wp.test/?p=11', 0, 'revision', '', 0),
(14, 1, '2022-11-24 11:06:53', '2022-11-24 11:06:53', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:11:"team-member";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Team Member Settings', 'team-member-settings', 'publish', 'closed', 'closed', '', 'group_637f4f19df32d', '', '', '2022-11-29 13:58:29', '2022-11-29 13:58:29', '', 0, 'https://js-school-wp.test/?post_type=acf-field-group&#038;p=14', 0, 'acf-field-group', '', 0),
(15, 1, '2022-11-24 11:06:53', '2022-11-24 11:06:53', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Position', 'js_school_wp_team_member_settings_position', 'publish', 'closed', 'closed', '', 'field_637f4f1aed9d8', '', '', '2022-11-24 11:06:53', '2022-11-24 11:06:53', '', 14, 'https://js-school-wp.test/?post_type=acf-field&p=15', 0, 'acf-field', '', 0),
(16, 1, '2022-11-24 11:06:53', '2022-11-24 11:06:53', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Photo', 'js_school_wp_team_member_settings_photo', 'publish', 'closed', 'closed', '', 'field_637f4fd2ed9d9', '', '', '2022-11-24 11:06:53', '2022-11-24 11:06:53', '', 14, 'https://js-school-wp.test/?post_type=acf-field&p=16', 1, 'acf-field', '', 0),
(17, 1, '2022-11-24 11:24:35', '2022-11-24 11:24:35', '', 'Troy Williams', '', 'publish', 'closed', 'closed', '', 'troy-williams', '', '', '2022-11-24 11:24:35', '2022-11-24 11:24:35', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=17', 0, 'team-member', '', 0),
(18, 1, '2022-11-24 11:24:03', '2022-11-24 11:24:03', '', '01', '', 'inherit', 'open', 'closed', '', '01', '', '', '2022-11-24 11:24:03', '2022-11-24 11:24:03', '', 17, 'https://js-school-wp.test/wp-content/uploads/2022/11/01.png', 0, 'attachment', 'image/png', 0),
(19, 1, '2022-11-24 11:26:08', '2022-11-24 11:26:08', '', 'Allan Meese', '', 'publish', 'closed', 'closed', '', 'allan-meese', '', '', '2022-11-24 11:26:08', '2022-11-24 11:26:08', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=19', 0, 'team-member', '', 0),
(20, 1, '2022-11-24 11:26:02', '2022-11-24 11:26:02', '', '02', '', 'inherit', 'open', 'closed', '', '02', '', '', '2022-11-24 11:26:02', '2022-11-24 11:26:02', '', 19, 'https://js-school-wp.test/wp-content/uploads/2022/11/02.png', 0, 'attachment', 'image/png', 0),
(21, 1, '2022-11-24 11:26:49', '2022-11-24 11:26:49', '', 'James Caras, Ph.D.', '', 'publish', 'closed', 'closed', '', 'james-caras-ph-d', '', '', '2022-11-24 11:26:49', '2022-11-24 11:26:49', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=21', 0, 'team-member', '', 0),
(22, 1, '2022-11-24 11:26:37', '2022-11-24 11:26:37', '', '03', '', 'inherit', 'open', 'closed', '', '03', '', '', '2022-11-24 11:26:37', '2022-11-24 11:26:37', '', 21, 'https://js-school-wp.test/wp-content/uploads/2022/11/03.png', 0, 'attachment', 'image/png', 0),
(23, 1, '2022-11-24 11:27:46', '2022-11-24 11:27:46', '', 'Ovi Jacob', '', 'publish', 'closed', 'closed', '', 'ovi-jacob', '', '', '2022-11-24 11:27:46', '2022-11-24 11:27:46', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=23', 0, 'team-member', '', 0),
(24, 1, '2022-11-24 11:27:32', '2022-11-24 11:27:32', '', '04', '', 'inherit', 'open', 'closed', '', '04', '', '', '2022-11-24 11:27:32', '2022-11-24 11:27:32', '', 23, 'https://js-school-wp.test/wp-content/uploads/2022/11/04.png', 0, 'attachment', 'image/png', 0),
(25, 1, '2022-11-24 11:28:20', '2022-11-24 11:28:20', '', 'Andrew McCann', '', 'publish', 'closed', 'closed', '', 'andrew-mccann', '', '', '2022-11-24 11:28:20', '2022-11-24 11:28:20', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=25', 0, 'team-member', '', 0),
(26, 1, '2022-11-24 11:28:10', '2022-11-24 11:28:10', '', '05', '', 'inherit', 'open', 'closed', '', '05', '', '', '2022-11-24 11:28:10', '2022-11-24 11:28:10', '', 25, 'https://js-school-wp.test/wp-content/uploads/2022/11/05.png', 0, 'attachment', 'image/png', 0),
(27, 1, '2022-11-24 11:29:20', '2022-11-24 11:29:20', '', 'Alex Von Rosenberg', '', 'publish', 'closed', 'closed', '', 'alex-von-rosenberg', '', '', '2022-11-24 11:29:20', '2022-11-24 11:29:20', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=27', 0, 'team-member', '', 0),
(28, 1, '2022-11-24 11:29:11', '2022-11-24 11:29:11', '', '06', '', 'inherit', 'open', 'closed', '', '06', '', '', '2022-11-24 11:29:11', '2022-11-24 11:29:11', '', 27, 'https://js-school-wp.test/wp-content/uploads/2022/11/06.png', 0, 'attachment', 'image/png', 0),
(29, 1, '2022-11-24 11:30:13', '2022-11-24 11:30:13', '', 'Kevin Pawsey', '', 'publish', 'closed', 'closed', '', 'kevin-pawsey', '', '', '2022-11-24 11:30:13', '2022-11-24 11:30:13', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=29', 0, 'team-member', '', 0),
(30, 1, '2022-11-24 11:29:58', '2022-11-24 11:29:58', '', '07', '', 'inherit', 'open', 'closed', '', '07', '', '', '2022-11-24 11:29:58', '2022-11-24 11:29:58', '', 29, 'https://js-school-wp.test/wp-content/uploads/2022/11/07.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2022-11-24 11:30:50', '2022-11-24 11:30:50', '', 'Mahendran Jawaharlal', '', 'publish', 'closed', 'closed', '', 'mahendran-jawaharlal', '', '', '2022-11-24 11:30:50', '2022-11-24 11:30:50', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=31', 0, 'team-member', '', 0),
(32, 1, '2022-11-24 11:30:44', '2022-11-24 11:30:44', '', '08', '', 'inherit', 'open', 'closed', '', '08', '', '', '2022-11-24 11:30:44', '2022-11-24 11:30:44', '', 31, 'https://js-school-wp.test/wp-content/uploads/2022/11/08.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2022-11-24 11:31:43', '2022-11-24 11:31:43', '', 'Jeff McCarthy', '', 'publish', 'closed', 'closed', '', 'jeff-mccarthy', '', '', '2022-11-28 13:20:25', '2022-11-28 13:20:25', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=33', 0, 'team-member', '', 0),
(34, 1, '2022-11-24 11:31:23', '2022-11-24 11:31:23', '', '09', '', 'inherit', 'open', 'closed', '', '09', '', '', '2022-11-24 11:31:23', '2022-11-24 11:31:23', '', 33, 'https://js-school-wp.test/wp-content/uploads/2022/11/09.png', 0, 'attachment', 'image/png', 0),
(35, 1, '2022-11-24 11:32:31', '2022-11-24 11:32:31', '', 'Gareth Hancock', '', 'publish', 'closed', 'closed', '', 'gareth-hancock', '', '', '2022-11-24 11:32:31', '2022-11-24 11:32:31', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=35', 0, 'team-member', '', 0),
(36, 1, '2022-11-24 11:32:17', '2022-11-24 11:32:17', '', '10', '', 'inherit', 'open', 'closed', '', '10', '', '', '2022-11-24 11:32:17', '2022-11-24 11:32:17', '', 35, 'https://js-school-wp.test/wp-content/uploads/2022/11/10.png', 0, 'attachment', 'image/png', 0),
(37, 1, '2022-11-24 11:33:04', '2022-11-24 11:33:04', '', 'Pratyush Rai', '', 'publish', 'closed', 'closed', '', 'pratyush-rai', '', '', '2022-11-24 11:33:04', '2022-11-24 11:33:04', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=37', 0, 'team-member', '', 0),
(38, 1, '2022-11-24 11:32:51', '2022-11-24 11:32:51', '', '11', '', 'inherit', 'open', 'closed', '', '11', '', '', '2022-11-24 11:32:51', '2022-11-24 11:32:51', '', 37, 'https://js-school-wp.test/wp-content/uploads/2022/11/11.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2022-11-24 11:33:37', '2022-11-24 11:33:37', '', 'Dan Silverburg', '', 'publish', 'closed', 'closed', '', 'dan-silverburg', '', '', '2022-11-24 11:33:37', '2022-11-24 11:33:37', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=39', 0, 'team-member', '', 0),
(40, 1, '2022-11-24 11:33:26', '2022-11-24 11:33:26', '', '12', '', 'inherit', 'open', 'closed', '', '12', '', '', '2022-11-24 11:33:26', '2022-11-24 11:33:26', '', 39, 'https://js-school-wp.test/wp-content/uploads/2022/11/12.png', 0, 'attachment', 'image/png', 0),
(41, 1, '2022-11-24 11:34:10', '2022-11-24 11:34:10', '', 'Sharon LaDay', '', 'publish', 'closed', 'closed', '', 'sharon-laday', '', '', '2022-11-24 11:34:10', '2022-11-24 11:34:10', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=41', 0, 'team-member', '', 0),
(42, 1, '2022-11-24 11:33:57', '2022-11-24 11:33:57', '', '13', '', 'inherit', 'open', 'closed', '', '13', '', '', '2022-11-24 11:33:57', '2022-11-24 11:33:57', '', 41, 'https://js-school-wp.test/wp-content/uploads/2022/11/13.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2022-11-24 11:34:50', '2022-11-24 11:34:50', '', 'Steve Renda', '', 'publish', 'closed', 'closed', '', 'steve-renda', '', '', '2022-11-24 11:34:50', '2022-11-24 11:34:50', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=43', 0, 'team-member', '', 0),
(44, 1, '2022-11-24 11:34:35', '2022-11-24 11:34:35', '', '14', '', 'inherit', 'open', 'closed', '', '14', '', '', '2022-11-24 11:34:35', '2022-11-24 11:34:35', '', 43, 'https://js-school-wp.test/wp-content/uploads/2022/11/14.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2022-11-24 11:35:24', '2022-11-24 11:35:24', '', 'Mike Berlin', '', 'publish', 'closed', 'closed', '', 'mike-berlin', '', '', '2022-11-24 11:35:24', '2022-11-24 11:35:24', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=45', 0, 'team-member', '', 0),
(46, 1, '2022-11-24 11:35:17', '2022-11-24 11:35:17', '', '15', '', 'inherit', 'open', 'closed', '', '15', '', '', '2022-11-24 11:35:17', '2022-11-24 11:35:17', '', 45, 'https://js-school-wp.test/wp-content/uploads/2022/11/15.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Mike Berlin', '', 'publish', 'closed', 'closed', '', 'mike-berlin-4', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=49', 0, 'team-member', '', 0),
(50, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Steve Renda', '', 'publish', 'closed', 'closed', '', 'steve-renda-4', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=50', 0, 'team-member', '', 0),
(51, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Sharon LaDay', '', 'publish', 'closed', 'closed', '', 'sharon-laday-4', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=51', 0, 'team-member', '', 0),
(52, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Dan Silverburg', '', 'publish', 'closed', 'closed', '', 'dan-silverburg-4', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=52', 0, 'team-member', '', 0),
(53, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Pratyush Rai', '', 'publish', 'closed', 'closed', '', 'pratyush-rai-4', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=53', 0, 'team-member', '', 0),
(54, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Gareth Hancock', '', 'publish', 'closed', 'closed', '', 'gareth-hancock-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=54', 0, 'team-member', '', 0),
(55, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Jeff McCarthy', '', 'publish', 'closed', 'closed', '', 'jeff-mccarthy-3', '', '', '2022-11-28 13:19:38', '2022-11-28 13:19:38', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=55', 0, 'team-member', '', 0),
(56, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Mahendran Jawaharlal', '', 'publish', 'closed', 'closed', '', 'mahendran-jawaharlal-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=56', 0, 'team-member', '', 0),
(57, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Kevin Pawsey', '', 'publish', 'closed', 'closed', '', 'kevin-pawsey-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=57', 0, 'team-member', '', 0),
(58, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Alex Von Rosenberg', '', 'publish', 'closed', 'closed', '', 'alex-von-rosenberg-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=58', 0, 'team-member', '', 0),
(59, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Andrew McCann', '', 'publish', 'closed', 'closed', '', 'andrew-mccann-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=59', 0, 'team-member', '', 0),
(60, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Ovi Jacob', '', 'publish', 'closed', 'closed', '', 'ovi-jacob-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=60', 0, 'team-member', '', 0),
(61, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'James Caras, Ph.D.', '', 'publish', 'closed', 'closed', '', 'james-caras-ph-d-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=61', 0, 'team-member', '', 0),
(62, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Allan Meese', '', 'publish', 'closed', 'closed', '', 'allan-meese-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=62', 0, 'team-member', '', 0),
(63, 1, '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 'Troy Williams', '', 'publish', 'closed', 'closed', '', 'troy-williams-3', '', '', '2022-11-24 13:10:06', '2022-11-24 13:10:06', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=63', 0, 'team-member', '', 0),
(64, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Mike Berlin', '', 'publish', 'closed', 'closed', '', 'mike-berlin-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=64', 0, 'team-member', '', 0),
(65, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Troy Williams', '', 'publish', 'closed', 'closed', '', 'troy-williams-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=65', 0, 'team-member', '', 0),
(66, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Allan Meese', '', 'publish', 'closed', 'closed', '', 'allan-meese-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=66', 0, 'team-member', '', 0),
(67, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'James Caras, Ph.D.', '', 'publish', 'closed', 'closed', '', 'james-caras-ph-d-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=67', 0, 'team-member', '', 0),
(68, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Ovi Jacob', '', 'publish', 'closed', 'closed', '', 'ovi-jacob-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=68', 0, 'team-member', '', 0),
(69, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Andrew McCann', '', 'publish', 'closed', 'closed', '', 'andrew-mccann-2', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=69', 0, 'team-member', '', 0),
(70, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Alex Von Rosenberg', '', 'publish', 'closed', 'closed', '', 'alex-von-rosenberg-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=70', 0, 'team-member', '', 0),
(71, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Kevin Pawsey', '', 'publish', 'closed', 'closed', '', 'kevin-pawsey-2', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=71', 0, 'team-member', '', 0),
(72, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Mahendran Jawaharlal', '', 'publish', 'closed', 'closed', '', 'mahendran-jawaharlal-2', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=72', 0, 'team-member', '', 0),
(73, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Steve Renda', '', 'publish', 'closed', 'closed', '', 'steve-renda-3', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=73', 0, 'team-member', '', 0),
(74, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Sharon LaDay', '', 'publish', 'closed', 'closed', '', 'sharon-laday-3', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=74', 0, 'team-member', '', 0),
(75, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Dan Silverburg', '', 'publish', 'closed', 'closed', '', 'dan-silverburg-2', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=75', 0, 'team-member', '', 0),
(76, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Pratyush Rai', '', 'publish', 'closed', 'closed', '', 'pratyush-rai-3', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=76', 0, 'team-member', '', 0),
(77, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Gareth Hancock', '', 'publish', 'closed', 'closed', '', 'gareth-hancock-2', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=77', 0, 'team-member', '', 0),
(78, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Jeff McCarthy', '', 'publish', 'closed', 'closed', '', 'jeff-mccarthy-2', '', '', '2022-11-28 13:20:03', '2022-11-28 13:20:03', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=78', 0, 'team-member', '', 0),
(79, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Mike Berlin', '', 'publish', 'closed', 'closed', '', 'mike-berlin-3', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=79', 0, 'team-member', '', 0),
(80, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Steve Renda', '', 'publish', 'closed', 'closed', '', 'steve-renda-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=80', 0, 'team-member', '', 0),
(81, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Sharon LaDay', '', 'publish', 'closed', 'closed', '', 'sharon-laday-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=81', 0, 'team-member', '', 0),
(82, 1, '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 'Dan Silverburg', '', 'publish', 'closed', 'closed', '', 'dan-silverburg-3', '', '', '2022-11-24 13:09:45', '2022-11-24 13:09:45', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=82', 0, 'team-member', '', 0),
(83, 1, '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 'Pratyush Rai', '', 'publish', 'closed', 'closed', '', 'pratyush-rai-2', '', '', '2022-11-24 13:09:44', '2022-11-24 13:09:44', '', 0, 'https://js-school-wp.test/?post_type=team-member&#038;p=83', 0, 'team-member', '', 0),
(84, 1, '2022-11-25 12:08:15', '2022-11-25 12:08:15', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2022-11-25 12:08:15', '2022-11-25 12:08:15', '', 0, 'https://js-school-wp.test/?page_id=84', 0, 'page', '', 0),
(85, 1, '2022-11-25 12:08:15', '2022-11-25 12:08:15', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '84-revision-v1', '', '', '2022-11-25 12:08:15', '2022-11-25 12:08:15', '', 84, 'https://js-school-wp.test/?p=85', 0, 'revision', '', 0),
(86, 1, '2022-11-29 08:12:55', '2022-11-29 08:12:55', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:8:"post_tag";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Tag Options', 'tag-options', 'publish', 'closed', 'closed', '', 'group_6385be325c249', '', '', '2022-11-29 13:58:05', '2022-11-29 13:58:05', '', 0, 'https://js-school-wp.test/?post_type=acf-field-group&#038;p=86', 0, 'acf-field-group', '', 0),
(87, 1, '2022-11-29 08:12:55', '2022-11-29 08:12:55', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";i:0;s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Followers', 'followers', 'publish', 'closed', 'closed', '', 'field_6385be37c2656', '', '', '2022-11-29 08:12:55', '2022-11-29 08:12:55', '', 86, 'https://js-school-wp.test/?post_type=acf-field&p=87', 0, 'acf-field', '', 0),
(88, 1, '2022-11-29 08:21:06', '2022-11-29 08:21:06', 'How would you explain JavaScript closures to someone with a knowledge of the concepts they consist of (for example functions, variables and the like), but does not understand closures themselves?\r\n\r\nI have seen <a href="http://en.wikipedia.org/wiki/Scheme_%28programming_language%29" rel="noreferrer">the Scheme example</a> given on Wikipedia, but unfortunately it did not help.', 'How do JavaScript closures work?', '', 'publish', 'open', 'open', '', 'how-do-javascript-closures-work', '', '', '2022-11-29 08:21:06', '2022-11-29 08:21:06', '', 0, 'https://js-school-wp.test/?p=88', 0, 'post', '', 0),
(89, 1, '2022-11-29 08:21:06', '2022-11-29 08:21:06', 'How would you explain JavaScript closures to someone with a knowledge of the concepts they consist of (for example functions, variables and the like), but does not understand closures themselves?\r\n\r\nI have seen <a href="http://en.wikipedia.org/wiki/Scheme_%28programming_language%29" rel="noreferrer">the Scheme example</a> given on Wikipedia, but unfortunately it did not help.', 'How do JavaScript closures work?', '', 'inherit', 'closed', 'closed', '', '88-revision-v1', '', '', '2022-11-29 08:21:06', '2022-11-29 08:21:06', '', 88, 'https://js-school-wp.test/?p=89', 0, 'revision', '', 0),
(91, 1, '2022-12-01 13:26:18', '2022-12-01 13:26:18', 'What is the scope of variables in javascript? Do they have the same scope inside as opposed to outside a function? Or does it even matter? Also, where are the variables stored if they are defined globally?', 'What is the scope of variables in JavaScript?', '', 'publish', 'open', 'open', '', 'hat-is-the-scope-of-variables-in-javascript', '', '', '2022-12-01 13:28:40', '2022-12-01 13:28:40', '', 0, 'https://js-school-wp.test/?p=91', 0, 'post', '', 0),
(92, 1, '2022-12-01 13:26:18', '2022-12-01 13:26:18', 'What is the scope of variables in javascript? Do they have the same scope inside as opposed to outside a function? Or does it even matter? Also, where are the variables stored if they are defined globally?', 'hat is the scope of variables in JavaScript?', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2022-12-01 13:26:18', '2022-12-01 13:26:18', '', 91, 'https://js-school-wp.test/?p=92', 0, 'revision', '', 0),
(93, 1, '2022-12-01 13:27:11', '2022-12-01 13:27:11', 'What is the scope of variables in javascript? Do they have the same scope inside as opposed to outside a function? Or does it even matter? Also, where are the variables stored if they are defined globally?', 'What is the scope of variables in JavaScript?', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2022-12-01 13:27:11', '2022-12-01 13:27:11', '', 91, 'https://js-school-wp.test/?p=93', 0, 'revision', '', 0),
(94, 1, '2022-12-01 13:28:12', '2022-12-01 13:28:12', 'ECMAScript 6 introduced <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/let" rel="noreferrer">the <code>let</code> statement</a>.\r\n\r\nI\'ve heard that it\'s described as a local variable, but I\'m still not quite sure how it behaves differently than the var keyword.\r\n\r\nWhat are the differences? When should <code>let</code> be used instead of <code>var</code>?', 'What is the difference between "let" and "var"?', '', 'publish', 'open', 'open', '', 'what-is-the-difference-between-let-and-var', '', '', '2022-12-01 13:28:12', '2022-12-01 13:28:12', '', 0, 'https://js-school-wp.test/?p=94', 0, 'post', '', 0),
(95, 1, '2022-12-01 13:28:12', '2022-12-01 13:28:12', 'ECMAScript 6 introduced <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/let" rel="noreferrer">the <code>let</code> statement</a>.\r\n\r\nI\'ve heard that it\'s described as a local variable, but I\'m still not quite sure how it behaves differently than the var keyword.\r\n\r\nWhat are the differences? When should <code>let</code> be used instead of <code>var</code>?', 'What is the difference between "let" and "var"?', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2022-12-01 13:28:12', '2022-12-01 13:28:12', '', 94, 'https://js-school-wp.test/?p=95', 0, 'revision', '', 0),
(96, 1, '2022-12-02 11:36:15', '2022-12-02 11:36:15', '', 'Massachusetts Institute of Technology', '', 'publish', 'closed', 'closed', '', 'massachusetts-institute-of-technology', '', '', '2022-12-02 11:36:15', '2022-12-02 11:36:15', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=96', 0, 'organization', '', 0),
(97, 1, '2022-12-02 11:36:24', '2022-12-02 11:36:24', '', 'Harvard University', '', 'publish', 'closed', 'closed', '', 'harvard-university', '', '', '2022-12-02 11:36:24', '2022-12-02 11:36:24', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=97', 0, 'organization', '', 0),
(98, 1, '2022-12-02 11:36:35', '2022-12-02 11:36:35', '', 'Stanford University', '', 'publish', 'closed', 'closed', '', 'stanford-university', '', '', '2022-12-02 11:36:35', '2022-12-02 11:36:35', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=98', 0, 'organization', '', 0),
(100, 1, '2022-12-02 11:36:45', '2022-12-02 11:36:45', '', 'Cornell University', '', 'publish', 'closed', 'closed', '', 'cornell-university', '', '', '2022-12-02 11:36:45', '2022-12-02 11:36:45', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=100', 0, 'organization', '', 0),
(101, 1, '2022-12-02 11:37:04', '2022-12-02 11:37:04', '', 'University of California, Berkeley', '', 'publish', 'closed', 'closed', '', 'university-of-california-berkeley', '', '', '2022-12-02 11:37:04', '2022-12-02 11:37:04', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=101', 0, 'organization', '', 0),
(102, 1, '2022-12-02 11:37:20', '2022-12-02 11:37:20', '', 'University of Michigan', '', 'publish', 'closed', 'closed', '', 'university-of-michigan', '', '', '2022-12-02 11:37:20', '2022-12-02 11:37:20', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=102', 0, 'organization', '', 0),
(103, 1, '2022-12-02 11:37:28', '2022-12-02 11:37:28', '', 'University of Washington', '', 'publish', 'closed', 'closed', '', 'university-of-washington', '', '', '2022-12-02 11:37:28', '2022-12-02 11:37:28', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=103', 0, 'organization', '', 0),
(104, 1, '2022-12-02 11:37:47', '2022-12-02 11:37:47', '', 'Columbia University in the City of New York', '', 'publish', 'closed', 'closed', '', 'columbia-university-in-the-city-of-new-york', '', '', '2022-12-02 11:37:47', '2022-12-02 11:37:47', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=104', 0, 'organization', '', 0),
(105, 1, '2022-12-02 11:37:51', '2022-12-02 11:37:51', '', 'University of California, Los Angeles', '', 'publish', 'closed', 'closed', '', 'university-of-california-los-angeles', '', '', '2022-12-02 11:37:51', '2022-12-02 11:37:51', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=105', 0, 'organization', '', 0),
(106, 1, '2022-12-02 11:38:22', '2022-12-02 11:38:22', '', 'Yale University', '', 'publish', 'closed', 'closed', '', 'yale-university', '', '', '2022-12-02 11:38:22', '2022-12-02 11:38:22', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=106', 0, 'organization', '', 0),
(107, 1, '2022-12-02 11:38:39', '2022-12-02 11:38:39', '', 'University of Pennsylvania', '', 'publish', 'closed', 'closed', '', 'university-of-pennsylvania', '', '', '2022-12-02 11:38:39', '2022-12-02 11:38:39', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=107', 0, 'organization', '', 0),
(108, 1, '2022-12-02 11:38:50', '2022-12-02 11:38:50', '', 'University of Minnesota-Twin Cities', '', 'publish', 'closed', 'closed', '', 'university-of-minnesota-twin-cities', '', '', '2022-12-02 11:38:50', '2022-12-02 11:38:50', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=108', 0, 'organization', '', 0),
(109, 1, '2022-12-02 11:39:00', '2022-12-02 11:39:00', '', 'University of Wisconsin-Madison', '', 'publish', 'closed', 'closed', '', 'university-of-wisconsin-madison', '', '', '2022-12-02 11:39:00', '2022-12-02 11:39:00', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=109', 0, 'organization', '', 0),
(110, 1, '2022-12-02 11:39:11', '2022-12-02 11:39:11', '', 'The University of Texas at Austin', '', 'publish', 'closed', 'closed', '', 'the-university-of-texas-at-austin', '', '', '2022-12-02 11:39:11', '2022-12-02 11:39:11', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=110', 0, 'organization', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(111, 1, '2022-12-02 11:39:21', '2022-12-02 11:39:21', '', 'Johns Hopkins University', '', 'publish', 'closed', 'closed', '', 'johns-hopkins-university', '', '', '2022-12-02 11:39:21', '2022-12-02 11:39:21', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=111', 0, 'organization', '', 0),
(113, 1, '2022-12-02 11:41:38', '2022-12-02 11:41:38', '', 'Princeton University', '', 'publish', 'closed', 'closed', '', 'princeton-university', '', '', '2022-12-02 11:41:38', '2022-12-02 11:41:38', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=113', 0, 'organization', '', 0),
(114, 1, '2022-12-02 11:41:44', '2022-12-02 11:41:44', '', 'University of Chicago', '', 'publish', 'closed', 'closed', '', 'university-of-chicago', '', '', '2022-12-02 11:41:44', '2022-12-02 11:41:44', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=114', 0, 'organization', '', 0),
(115, 1, '2022-12-02 11:42:09', '2022-12-02 11:42:09', '', 'Purdue University', '', 'publish', 'closed', 'closed', '', 'purdue-university', '', '', '2022-12-02 11:42:09', '2022-12-02 11:42:09', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=115', 0, 'organization', '', 0),
(116, 1, '2022-12-02 11:42:21', '2022-12-02 11:42:21', '', 'University of California, San Diego', '', 'publish', 'closed', 'closed', '', 'university-of-california-san-diego', '', '', '2022-12-02 11:42:21', '2022-12-02 11:42:21', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=116', 0, 'organization', '', 0),
(117, 1, '2022-12-02 11:42:35', '2022-12-02 11:42:35', '', 'New York University', '', 'publish', 'closed', 'closed', '', 'new-york-university', '', '', '2022-12-02 11:42:35', '2022-12-02 11:42:35', '', 0, 'https://js-school-wp.test/?post_type=organization&#038;p=117', 0, 'organization', '', 0),
(118, 1, '2022-12-09 09:56:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-12-09 09:56:31', '0000-00-00 00:00:00', '', 0, 'https://js-school-wp.test/?p=118', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_registration_log`
#

DROP TABLE IF EXISTS `wp_registration_log`;


#
# Table structure of table `wp_registration_log`
#

CREATE TABLE `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT 0,
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_registration_log`
#
INSERT INTO `wp_registration_log` ( `ID`, `email`, `IP`, `blog_id`, `date_registered`) VALUES
(1, 'anamarija.papic@agilo.co', '172.18.0.1', 2, '2022-12-12 13:22:33') ;

#
# End of data contents of table `wp_registration_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_signups`
#

DROP TABLE IF EXISTS `wp_signups`;


#
# Table structure of table `wp_signups`
#

CREATE TABLE `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `title` longtext NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `activation_key` varchar(50) NOT NULL DEFAULT '',
  `meta` longtext DEFAULT NULL,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_signups`
#

#
# End of data contents of table `wp_signups`
# --------------------------------------------------------



#
# Delete any existing table `wp_site`
#

DROP TABLE IF EXISTS `wp_site`;


#
# Table structure of table `wp_site`
#

CREATE TABLE `wp_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_site`
#
INSERT INTO `wp_site` ( `id`, `domain`, `path`) VALUES
(1, 'js-school-wp-1.test', '/') ;

#
# End of data contents of table `wp_site`
# --------------------------------------------------------



#
# Delete any existing table `wp_sitemeta`
#

DROP TABLE IF EXISTS `wp_sitemeta`;


#
# Table structure of table `wp_sitemeta`
#

CREATE TABLE `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_sitemeta`
#
INSERT INTO `wp_sitemeta` ( `meta_id`, `site_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'site_name', 'JS School Sites'),
(2, 1, 'admin_email', 'anamarija.papic@agilo.co'),
(3, 1, 'admin_user_id', '1'),
(4, 1, 'registration', 'none'),
(5, 1, 'upload_filetypes', 'jpg jpeg png gif webp mov avi mpg 3gp 3g2 midi mid pdf doc ppt odt pptx docx pps ppsx xls xlsx key mp3 ogg flac m4a wav mp4 m4v webm ogv flv'),
(6, 1, 'blog_upload_space', '100'),
(7, 1, 'fileupload_maxk', '1500'),
(8, 1, 'site_admins', 'a:1:{i:0;s:9:"anamarija";}'),
(9, 1, 'allowedthemes', 'a:2:{s:12:"js-school-wp";b:1;s:17:"twentytwentythree";b:1;}'),
(10, 1, 'illegal_names', 'a:8:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";}'),
(11, 1, 'wpmu_upgrade_site', '53496'),
(12, 1, 'welcome_email', 'Howdy USERNAME,\n\nYour new SITE_NAME site has been successfully set up at:\nBLOG_URL\n\nYou can log in to the administrator account with the following information:\n\nUsername: USERNAME\nPassword: PASSWORD\nLog in here: BLOG_URLwp-login.php\n\nWe hope you enjoy your new site. Thanks!\n\n--The Team @ SITE_NAME'),
(13, 1, 'first_post', 'Welcome to %s. This is your first post. Edit or delete it, then start writing!'),
(14, 1, 'siteurl', 'https://js-school-wp-1.test/'),
(15, 1, 'add_new_users', '0'),
(16, 1, 'upload_space_check_disabled', '1'),
(17, 1, 'subdomain_install', '1'),
(18, 1, 'ms_files_rewriting', '0'),
(19, 1, 'user_count', '1'),
(20, 1, 'initial_db_version', '53496'),
(21, 1, 'active_sitewide_plugins', 'a:11:{s:31:"query-monitor/query-monitor.php";i:1670852367;s:34:"advanced-custom-fields-pro/acf.php";i:1670852366;s:33:"classic-editor/classic-editor.php";i:1670852366;s:23:"debug-bar/debug-bar.php";i:1670852366;s:74:"debug-bar-actions-and-filters-addon/debug-bar-action-and-filters-addon.php";i:1670852366;s:41:"debug-bar-rewrite-rules/rewrite-rules.php";i:1670852366;s:27:"svg-support/svg-support.php";i:1670852366;s:27:"wp-crontrol/wp-crontrol.php";i:1670852366;s:31:"wp-migrate-db/wp-migrate-db.php";i:1670852366;s:33:"duplicate-post/duplicate-post.php";i:1670852366;s:24:"wordpress-seo/wp-seo.php";i:1670852367;}'),
(22, 1, 'WPLANG', 'en_US'),
(23, 1, 'main_site', '1'),
(24, 1, 'nonce_key', 'v{tnKAeP^CfL]`m_wK[%3mNq:4gka9C4$B#]QD``G/C)n2lUtW|i#j}Bt)nx&44b'),
(25, 1, 'nonce_salt', '/}=?uAypn$h}?}y%9VfVL_AVEMUOv(qenLsE#bVCNG,Ep{tWUmgb>.g_RuP47/>Z'),
(26, 1, 'secure_auth_key', 'bD?U-kl(P8c>{0hb[ ,>At|~myphM_:XR121FSE*^S7s1/G!-2`QUiG{8QjDs/pw'),
(27, 1, 'secure_auth_salt', 'Hi=r*YiCc9(lsK_(fkUD~I>+_ jNFc)b$gic=1H9KQZys|6w9Uuc]j!58Wna?3Bl'),
(28, 1, 'logged_in_key', 'wiL::8Mt|)9m((`7yc-7iY2FC-Q-!cRLvo7kAr~Lh7Vjg|C!/H@9OX#yJ|7<f%p4'),
(29, 1, 'logged_in_salt', 'XZwa9,-8g;KSv,*X%gQAR@@wdqlZvarK9+>spejYe}AL&(g>L3uP]U8g31WyOXEy'),
(35, 1, 'can_compress_scripts', '1'),
(42, 1, 'site_meta_supported', '1'),
(45, 1, 'blog_count', '2'),
(46, 1, 'wp_force_deactivated_plugins', 'a:0:{}'),
(47, 1, 'registrationnotification', 'yes'),
(48, 1, 'welcome_user_email', 'Howdy USERNAME,\n\nYour new account is set up.\n\nYou can log in with the following information:\nUsername: USERNAME\nPassword: PASSWORD\nLOGINLINK\n\nThanks!\n\n--The Team @ SITE_NAME'),
(49, 1, 'recently_activated', 'a:0:{}'),
(50, 1, 'wpseo_ms', 'a:46:{s:6:"access";s:5:"admin";s:11:"defaultblog";s:0:"";s:26:"allow_disableadvanced_meta";b:1;s:23:"allow_ryte_indexability";b:0;s:29:"allow_content_analysis_active";b:1;s:29:"allow_keyword_analysis_active";b:1;s:40:"allow_inclusive_language_analysis_active";b:1;s:27:"allow_enable_admin_bar_menu";b:1;s:32:"allow_enable_cornerstone_content";b:1;s:24:"allow_enable_xml_sitemap";b:1;s:30:"allow_enable_text_link_counter";b:1;s:36:"allow_enable_headless_rest_endpoints";b:1;s:29:"allow_enable_metabox_insights";b:1;s:29:"allow_enable_link_suggestions";b:1;s:14:"allow_tracking";b:1;s:35:"allow_enable_enhanced_slack_sharing";b:1;s:32:"allow_semrush_integration_active";b:1;s:31:"allow_zapier_integration_active";b:1;s:32:"allow_wincher_integration_active";b:0;s:24:"allow_remove_feed_global";b:1;s:33:"allow_remove_feed_global_comments";b:1;s:31:"allow_remove_feed_post_comments";b:1;s:22:"allow_enable_index_now";b:1;s:25:"allow_remove_feed_authors";b:1;s:28:"allow_remove_feed_categories";b:1;s:22:"allow_remove_feed_tags";b:1;s:35:"allow_remove_feed_custom_taxonomies";b:1;s:28:"allow_remove_feed_post_types";b:1;s:24:"allow_remove_feed_search";b:1;s:27:"allow_remove_atom_rdf_feeds";b:1;s:23:"allow_remove_shortlinks";b:1;s:27:"allow_remove_rest_api_links";b:1;s:26:"allow_remove_rsd_wlw_links";b:1;s:25:"allow_remove_oembed_links";b:1;s:22:"allow_remove_generator";b:1;s:26:"allow_remove_emoji_scripts";b:1;s:30:"allow_remove_powered_by_header";b:1;s:28:"allow_remove_pingback_header";b:1;s:34:"allow_clean_campaign_tracking_urls";b:1;s:22:"allow_clean_permalinks";b:1;s:20:"allow_search_cleanup";b:1;s:26:"allow_search_cleanup_emoji";b:1;s:29:"allow_search_cleanup_patterns";b:1;s:33:"allow_redirect_search_pretty_urls";b:1;s:34:"allow_wordproof_integration_active";b:0;s:32:"allow_algolia_integration_active";b:1;}'),
(55, 1, 'auth_key', 'ZT1^pCY=6,T&$so)*oJaaXs%9}$++_co:M,dMh1Knt0q<b{&tH8#{9Q(2!xk%o!4'),
(56, 1, 'auth_salt', 'ae&]QqMU:}B+fn#Eht*wSwYt=-e*Bv6)miFnxUujaY.BcK`4gCQT{`;Pgn]UyGL}'),
(83, 1, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1671100354;}') ;

#
# End of data contents of table `wp_sitemeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(88, 1, 0),
(88, 2, 0),
(88, 3, 0),
(88, 4, 0),
(91, 1, 0),
(91, 2, 0),
(91, 3, 0),
(91, 5, 0),
(91, 6, 0),
(91, 8, 0),
(94, 1, 0),
(94, 2, 0),
(94, 3, 0),
(94, 7, 0),
(94, 8, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'post_tag', 'For questions about programming in ECMAScript (JavaScript/JS) and its different dialects/implementations (except for ActionScript). Keep in mind that JavaScript is NOT the same as Java! Include all labels that are relevant to your question; e.g., [node.js], [jQuery], [JSON], [ReactJS], [angular], [ember.js], [vue.js], [typescript], [svelte], etc.', 0, 3),
(3, 3, 'post_tag', 'Scope is an enclosing context where values and expressions are associated. Use this tag for questions about different types of scope as well for questions where scope may be unclear.', 0, 3),
(4, 4, 'post_tag', 'A closure is a first-class function that refers to (closes over) variables from the scope in which it was defined. If the closure still exists after its defining scope ends, the variables it closes over will continue to exist as well.', 0, 1),
(5, 5, 'post_tag', 'A function (also called a procedure, method, subroutine, or routine or macro) is a portion of code intended to carry out a single, specific task. Use this tag for questions which specifically involve creating or calling functions. For help implementing a function to perform a task, use [algorithm] or a task-specific tag instead. By creating function the logic can be isolated and can be called repeatedly.', 0, 1),
(6, 6, 'post_tag', 'THIS IS AMBIGUOUS; USE SPECIFIC-LANGUAGE TAGS WHENEVER APPLICABLE. A variable is a named data storage location in memory. Using variables, a computer program can store numbers, text, binary data, or a combination of any of these data types. They can be passed around in the program.', 0, 1),
(7, 7, 'post_tag', 'In Lisp-like and functional languages, introduces a list of local variables, each (possibly optionally) with its initial value.', 0, 1),
(8, 8, 'post_tag', 'var is a keyword in a number of programming languages.', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'followers', '397400'),
(2, 2, '_followers', 'field_6385be37c2656'),
(3, 3, 'followers', '158'),
(4, 3, '_followers', 'field_6385be37c2656'),
(5, 4, 'followers', '314'),
(6, 4, '_followers', 'field_6385be37c2656'),
(7, 8, 'followers', '271'),
(8, 8, '_followers', 'field_6385be37c2656'),
(9, 7, 'followers', '58'),
(10, 7, '_followers', 'field_6385be37c2656'),
(11, 5, 'followers', '32000'),
(12, 5, '_followers', 'field_6385be37c2656'),
(13, 6, 'followers', '693'),
(14, 6, '_followers', 'field_6385be37c2656') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'javascript', 'javascript', 0),
(3, 'scope', 'scope', 0),
(4, 'closures', 'closures', 0),
(5, 'function', 'function', 0),
(6, 'variables', 'variables', 0),
(7, 'let', 'let', 0),
(8, 'var', 'var', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'anamarija'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:6:{s:64:"c41a946815ea54c253b5e4cc0f108e4d59c05479e25694b587dfac761264389d";a:4:{s:10:"expiration";i:1671178872;s:2:"ip";s:10:"172.18.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671006072;}s:64:"aa789108b7cb7456752692e1eb5a934d0d1eff7912b21ade63373f9112b8542f";a:4:{s:10:"expiration";i:1671263021;s:2:"ip";s:10:"172.18.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671090221;}s:64:"71070cca6687b6a4b0fb0b8a6710469291da0a89c9ef97c195308eca7e6ba86c";a:4:{s:10:"expiration";i:1671263224;s:2:"ip";s:10:"172.18.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671090424;}s:64:"80ae50d2462e547a57f1eab5ecc1fcb1c7de4528b6fcca2ba10cdbe7e8b91948";a:4:{s:10:"expiration";i:1671264128;s:2:"ip";s:10:"172.20.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671091328;}s:64:"3e0dbace634190f5ac99f09409f4ce1d450bc4f63e1562e763c3a5d26c127809";a:4:{s:10:"expiration";i:1671265882;s:2:"ip";s:10:"172.24.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671093082;}s:64:"fcaff5b677346055b7fde78cf4adefd8b72592cc28710ade5851959bb9a6300d";a:4:{s:10:"expiration";i:1671265951;s:2:"ip";s:10:"172.24.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1671093151;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '118'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:10:"172.24.0.0";}'),
(20, 1, '_yoast_wpseo_profile_updated', '1670852487'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1669289070'),
(24, 1, 'source_domain', 'js-school-wp.test'),
(25, 1, 'primary_blog', '1'),
(26, 1, 'wp_2_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(27, 1, 'wp_2_user_level', '10'),
(28, 1, 'wp_2_dashboard_quick_press_last_post_id', '3'),
(29, 1, 'wp_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:479:"<p><strong>Huge SEO Issue: You&#039;re blocking access to robots.</strong> If you want search engines to show this site in their results, you must <a href="https://js-school-wp.test/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility. <button type="button" id="robotsmessage-dismiss-button" class="button-link hide-if-no-js" data-nonce="70c56e0847">I don&#039;t want this site to show in the search results.</button></p>";s:7:"options";a:10:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-search-engines-discouraged";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":12:{s:2:"ID";s:1:"1";s:10:"user_login";s:9:"anamarija";s:9:"user_pass";s:34:"$P$BrhIFPVzcLYkWvxt.1vwUge1Mh4lJP/";s:13:"user_nicename";s:9:"anamarija";s:10:"user_email";s:24:"anamarija.papic@agilo.co";s:8:"user_url";s:25:"https://js-school-wp.test";s:15:"user_registered";s:19:"2022-11-23 12:53:39";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:9:"anamarija";s:4:"spam";s:1:"0";s:7:"deleted";s:1:"0";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:64:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:10:"copy_posts";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:1;a:2:{s:7:"message";s:295:"<p>Because of a change in your permalink structure, some of your SEO data needs to be reprocessed.</p><p>We estimate this will take less than a minute.</p><a class="button" href="https://js-school-wp.test/wp-admin/admin.php?page=wpseo_tools&start-indexation=true">Start SEO data optimization</a>";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:13:"wpseo-reindex";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":12:{s:2:"ID";s:1:"1";s:10:"user_login";s:9:"anamarija";s:9:"user_pass";s:34:"$P$BrhIFPVzcLYkWvxt.1vwUge1Mh4lJP/";s:13:"user_nicename";s:9:"anamarija";s:10:"user_email";s:24:"anamarija.papic@agilo.co";s:8:"user_url";s:25:"https://js-school-wp.test";s:15:"user_registered";s:19:"2022-11-23 12:53:39";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:9:"anamarija";s:4:"spam";s:1:"0";s:7:"deleted";s:1:"0";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:64:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:10:"copy_posts";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}'),
(31, 1, 'wp_2_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";O:61:"Yoast\\WP\\SEO\\Presenters\\Admin\\Indexing_Notification_Presenter":6:{s:18:"\0*\0total_unindexed";i:5;s:9:"\0*\0reason";s:26:"permalink_settings_changed";s:20:"\0*\0short_link_helper";O:38:"Yoast\\WP\\SEO\\Helpers\\Short_Link_Helper":2:{s:17:"\0*\0options_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Options_Helper":0:{}s:17:"\0*\0product_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Product_Helper":0:{}}s:15:"total_unindexed";i:5;s:6:"reason";s:26:"permalink_settings_changed";s:17:"short_link_helper";O:38:"Yoast\\WP\\SEO\\Helpers\\Short_Link_Helper":4:{s:17:"\0*\0options_helper";r:7;s:17:"\0*\0product_helper";r:8;s:14:"options_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Options_Helper":0:{}s:14:"product_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Product_Helper":0:{}}}s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:13:"wpseo-reindex";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":12:{s:2:"ID";s:1:"1";s:10:"user_login";s:9:"anamarija";s:9:"user_pass";s:34:"$P$BrhIFPVzcLYkWvxt.1vwUge1Mh4lJP/";s:13:"user_nicename";s:9:"anamarija";s:10:"user_email";s:24:"anamarija.papic@agilo.co";s:8:"user_url";s:25:"https://js-school-wp.test";s:15:"user_registered";s:19:"2022-11-23 12:53:39";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:9:"anamarija";s:4:"spam";s:1:"0";s:7:"deleted";s:1:"0";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:17:"wp_2_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:64:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:10:"copy_posts";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:2;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT 0,
  `deleted` tinyint(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`, `spam`, `deleted`) VALUES
(1, 'anamarija', '$P$BrhIFPVzcLYkWvxt.1vwUge1Mh4lJP/', 'anamarija', 'anamarija.papic@agilo.co', 'https://js-school-wp.test', '2022-11-23 12:53:39', '', 0, 'anamarija', 0, 0) ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext DEFAULT NULL,
  `permalink_hash` varchar(40) DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) NOT NULL,
  `object_sub_type` varchar(32) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `breadcrumb_title` text DEFAULT NULL,
  `post_status` varchar(20) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext DEFAULT NULL,
  `primary_focus_keyword` varchar(191) DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text DEFAULT NULL,
  `twitter_image` longtext DEFAULT NULL,
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image_id` varchar(191) DEFAULT NULL,
  `twitter_image_source` text DEFAULT NULL,
  `open_graph_title` text DEFAULT NULL,
  `open_graph_description` longtext DEFAULT NULL,
  `open_graph_image` longtext DEFAULT NULL,
  `open_graph_image_id` varchar(191) DEFAULT NULL,
  `open_graph_image_source` text DEFAULT NULL,
  `open_graph_image_meta` mediumtext DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  `schema_page_type` varchar(64) DEFAULT NULL,
  `schema_article_type` varchar(64) DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'https://js-school-wp.test/author/anamarija/', '43:41a85a83d907708bd9fffe9fe7425608', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://secure.gravatar.com/avatar/0da7ff9fa2df592ba150b037d8653d22?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://secure.gravatar.com/avatar/0da7ff9fa2df592ba150b037d8653d22?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2022-11-24 07:53:30', '2022-12-13 07:50:39', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-13 07:50:34', '2022-11-23 12:53:39'),
(4, 'https://js-school-wp.test/2022/11/23/hello-world/', '49:e6515f5970d04816868da2999bbb47c2', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 07:53:30', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-11-23 12:53:39', '2022-11-23 12:53:39'),
(5, 'https://js-school-wp.test/category/uncategorized/', '49:4f022005a10d2fa8744a45e5ad0a7fcf', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Uncategorized', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 07:53:30', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-11-23 12:53:39'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-24 07:53:30', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-24 07:53:30', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-24 07:53:30', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'https://js-school-wp.test/', '26:614fccffd8f128d9c9b1a195b86ed841', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', '', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2022-11-24 07:53:30', '2022-12-13 07:50:39', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-13 07:50:34', '2022-11-23 12:53:39'),
(10, 'https://js-school-wp.test/infinite-scroll/', '42:9b23d84213d0d6d3d36ae4a89110d2f5', 6, 'post', 'page', 1, 0, NULL, NULL, 'Infinite scroll', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 08:20:10', '2022-12-13 07:50:23', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 08:20:40', '2022-11-24 08:20:40'),
(11, 'https://js-school-wp.test/stackoverflow-tags/', '45:4ad533af9015dc31307b2731baa22154', 8, 'post', 'page', 1, 0, NULL, NULL, 'Stackoverflow tags', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 08:20:55', '2022-12-13 07:50:23', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 08:20:55', '2022-11-24 08:20:55'),
(12, 'https://js-school-wp.test/autocomplete-menu-cors-endpoint/', '58:bb0b829cc8a4291ae4da722a686b4215', 10, 'post', 'page', 1, 0, NULL, NULL, 'Autocomplete menu &#038; CORS endpoint', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 08:21:12', '2022-12-12 13:44:29', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 08:21:12', '2022-11-24 08:21:12'),
(13, 'https://js-school-wp.test/team-members/', '39:32b71b5851012582cb05679c6d6ada8e', NULL, 'post-type-archive', 'team-member', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Team Members', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-24 10:47:50', '2022-12-13 08:12:28', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-11-28 13:20:25', '2022-11-24 11:24:35'),
(14, NULL, NULL, 14, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Team Member Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:06:53', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-11-29 13:58:29', '2022-11-24 11:06:53'),
(15, NULL, NULL, 15, 'post', 'acf-field', 1, 14, NULL, NULL, 'Position', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:06:53', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-11-24 11:06:53', '2022-11-24 11:06:53'),
(16, NULL, NULL, 16, 'post', 'acf-field', 1, 14, NULL, NULL, 'Photo', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:06:53', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-11-24 11:06:53', '2022-11-24 11:06:53'),
(17, 'https://js-school-wp.test/team-members/troy-williams/', '53:254dbf4a94540e47a5e1f37b09acc74f', 17, 'post', 'team-member', 1, 0, NULL, NULL, 'Troy Williams', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:10:59', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:24:35', '2022-11-24 11:24:35'),
(18, 'https://js-school-wp.test/wp-content/uploads/2022/11/01.png', '59:70c97919046c4879c6be21666457df32', 18, 'post', 'attachment', 1, 17, NULL, NULL, '01', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/01.png', NULL, '18', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/01.png', '18', 'attachment-image', '{"width":504,"height":508,"filesize":599289,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/01.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/01.png","size":"full","id":18,"alt":"","pixels":256032,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:24:03', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:24:03', '2022-11-24 11:24:03'),
(19, 'https://js-school-wp.test/team-members/allan-meese/', '51:7b421b7edfc08106461c40fb014a6816', 19, 'post', 'team-member', 1, 0, NULL, NULL, 'Allan Meese', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:25:45', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:26:08', '2022-11-24 11:26:08'),
(20, 'https://js-school-wp.test/wp-content/uploads/2022/11/02.png', '59:ed3f85bf9c6cca73e5455182ddf0f2cc', 20, 'post', 'attachment', 1, 19, NULL, NULL, '02', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/02.png', NULL, '20', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/02.png', '20', 'attachment-image', '{"width":506,"height":506,"filesize":484406,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/02.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/02.png","size":"full","id":20,"alt":"","pixels":256036,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:26:02', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:26:02', '2022-11-24 11:26:02'),
(21, 'https://js-school-wp.test/team-members/james-caras-ph-d/', '56:711d2760e5f2a5a060c0d1dca7b09666', 21, 'post', 'team-member', 1, 0, NULL, NULL, 'James Caras, Ph.D.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:26:22', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:26:49', '2022-11-24 11:26:49'),
(22, 'https://js-school-wp.test/wp-content/uploads/2022/11/03.png', '59:eb22b4968c80e8cf9747e11f4f54a93e', 22, 'post', 'attachment', 1, 21, NULL, NULL, '03', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/03.png', NULL, '22', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/03.png', '22', 'attachment-image', '{"width":510,"height":510,"filesize":497435,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/03.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/03.png","size":"full","id":22,"alt":"","pixels":260100,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:26:37', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:26:37', '2022-11-24 11:26:37'),
(23, 'https://js-school-wp.test/team-members/ovi-jacob/', '49:d115c935f3281e1715401ac6e0787032', 23, 'post', 'team-member', 1, 0, NULL, NULL, 'Ovi Jacob', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:27:46', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:27:46', '2022-11-24 11:27:46'),
(24, 'https://js-school-wp.test/team-members/andrew-mccann/', '53:f4e1ac8ab994d5b6c7aa254bbab38a22', 25, 'post', 'team-member', 1, 0, NULL, NULL, 'Andrew McCann', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:28:01', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:28:20', '2022-11-24 11:28:20'),
(25, 'https://js-school-wp.test/wp-content/uploads/2022/11/05.png', '59:ce9eb9d7b3b2895f723f90d226519132', 26, 'post', 'attachment', 1, 25, NULL, NULL, '05', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/05.png', NULL, '26', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/05.png', '26', 'attachment-image', '{"width":506,"height":510,"filesize":432941,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/05.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/05.png","size":"full","id":26,"alt":"","pixels":258060,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:28:10', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:28:10', '2022-11-24 11:28:10'),
(26, 'https://js-school-wp.test/team-members/alex-von-rosenberg/', '58:5dc235d55c0ed0eaa3b5bd6d75583dfb', 27, 'post', 'team-member', 1, 0, NULL, NULL, 'Alex Von Rosenberg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:28:44', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:29:20', '2022-11-24 11:29:20'),
(27, 'https://js-school-wp.test/wp-content/uploads/2022/11/06.png', '59:5e5b2809b8a5aff5d660231d06fbf3ab', 28, 'post', 'attachment', 1, 27, NULL, NULL, '06', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/06.png', NULL, '28', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/06.png', '28', 'attachment-image', '{"width":508,"height":512,"filesize":561990,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/06.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/06.png","size":"full","id":28,"alt":"","pixels":260096,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:29:11', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:29:11', '2022-11-24 11:29:11'),
(28, 'https://js-school-wp.test/team-members/kevin-pawsey/', '52:4c8c0ebfaf17419e3368cfed0b16e7f1', 29, 'post', 'team-member', 1, 0, NULL, NULL, 'Kevin Pawsey', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:29:41', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:30:13', '2022-11-24 11:30:13'),
(29, 'https://js-school-wp.test/wp-content/uploads/2022/11/07.png', '59:0e3fd00339bfe47d2b17935cad10bf3b', 30, 'post', 'attachment', 1, 29, NULL, NULL, '07', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/07.png', NULL, '30', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/07.png', '30', 'attachment-image', '{"width":502,"height":506,"filesize":434957,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/07.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/07.png","size":"full","id":30,"alt":"","pixels":254012,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:29:58', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:29:58', '2022-11-24 11:29:58'),
(30, 'https://js-school-wp.test/team-members/mahendran-jawaharlal/', '60:c932a34f7ed2829c277d6e9a855959af', 31, 'post', 'team-member', 1, 0, NULL, NULL, 'Mahendran Jawaharlal', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:30:50', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:30:50', '2022-11-24 11:30:50'),
(31, 'https://js-school-wp.test/team-members/jeff-mccarthy/', '53:48fb9460fc9bb2d5d65f3a9328f432ed', 33, 'post', 'team-member', 1, 0, NULL, NULL, 'Jeff McCarthy', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:31:07', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-28 13:20:25', '2022-11-24 11:31:43'),
(32, 'https://js-school-wp.test/wp-content/uploads/2022/11/09.png', '59:619b64730e629af42a4b7c4ff993ffd3', 34, 'post', 'attachment', 1, 33, NULL, NULL, '09', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/09.png', NULL, '34', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/09.png', '34', 'attachment-image', '{"width":506,"height":506,"filesize":452727,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/09.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/09.png","size":"full","id":34,"alt":"","pixels":256036,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:31:23', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:31:23', '2022-11-24 11:31:23'),
(33, 'https://js-school-wp.test/team-members/gareth-hancock/', '54:f47ed569fe1c934c8a1821140dfd4a9f', 35, 'post', 'team-member', 1, 0, NULL, NULL, 'Gareth Hancock', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:32:02', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:32:31', '2022-11-24 11:32:31'),
(34, 'https://js-school-wp.test/wp-content/uploads/2022/11/10.png', '59:9c74fbb3d4e05e24a82aee69896f4c1d', 36, 'post', 'attachment', 1, 35, NULL, NULL, '10', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/10.png', NULL, '36', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/10.png', '36', 'attachment-image', '{"width":508,"height":512,"filesize":522991,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/10.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/10.png","size":"full","id":36,"alt":"","pixels":260096,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:32:17', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:32:17', '2022-11-24 11:32:17'),
(35, 'https://js-school-wp.test/team-members/pratyush-rai/', '52:6704a414054670e0870c3223b4899757', 37, 'post', 'team-member', 1, 0, NULL, NULL, 'Pratyush Rai', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:33:04', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:33:04', '2022-11-24 11:33:04'),
(36, 'https://js-school-wp.test/team-members/dan-silverburg/', '54:9dae5c2b9f3582874ec972006b8e4a8c', 39, 'post', 'team-member', 1, 0, NULL, NULL, 'Dan Silverburg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:33:15', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:33:37', '2022-11-24 11:33:37'),
(37, 'https://js-school-wp.test/wp-content/uploads/2022/11/12.png', '59:57ebc67329f8ba578f46784b2f579e49', 40, 'post', 'attachment', 1, 39, NULL, NULL, '12', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/12.png', NULL, '40', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/12.png', '40', 'attachment-image', '{"width":506,"height":510,"filesize":406698,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/12.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/12.png","size":"full","id":40,"alt":"","pixels":258060,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:33:26', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:33:26', '2022-11-24 11:33:26'),
(38, 'https://js-school-wp.test/team-members/sharon-laday/', '52:902e2b222d49065266679ae7400707e1', 41, 'post', 'team-member', 1, 0, NULL, NULL, 'Sharon LaDay', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:34:10', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:34:10', '2022-11-24 11:34:10'),
(39, 'https://js-school-wp.test/team-members/steve-renda/', '51:49e5be69008352ff9710f069e9ebaf59', 43, 'post', 'team-member', 1, 0, NULL, NULL, 'Steve Renda', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:34:21', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:34:50', '2022-11-24 11:34:50'),
(40, 'https://js-school-wp.test/wp-content/uploads/2022/11/14.png', '59:2453130c2d0925e5df0f806c5b05ccb0', 44, 'post', 'attachment', 1, 43, NULL, NULL, '14', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/14.png', NULL, '44', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/14.png', '44', 'attachment-image', '{"width":506,"height":510,"filesize":445784,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/14.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/14.png","size":"full","id":44,"alt":"","pixels":258060,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 11:34:35', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:34:35', '2022-11-24 11:34:35'),
(41, 'https://js-school-wp.test/team-members/mike-berlin/', '51:2cee29bea5eb8c6683ba2218e77bf4e5', 45, 'post', 'team-member', 1, 0, NULL, NULL, 'Mike Berlin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 11:35:24', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 11:35:24', '2022-11-24 11:35:24'),
(42, 'https://js-school-wp.test/wp-content/uploads/2022/11/04.png', '59:ce206c19ba0155d89d888c8517bab5c5', 24, 'post', 'attachment', 1, 23, NULL, NULL, '04', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/04.png', NULL, '24', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/04.png', '24', 'attachment-image', '{"width":508,"height":508,"filesize":484120,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/04.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/04.png","size":"full","id":24,"alt":"","pixels":258064,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 13:05:27', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:27:32', '2022-11-24 11:27:32'),
(43, 'https://js-school-wp.test/wp-content/uploads/2022/11/08.png', '59:b23b953d86747a3af009885690797e19', 32, 'post', 'attachment', 1, 31, NULL, NULL, '08', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/08.png', NULL, '32', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/08.png', '32', 'attachment-image', '{"width":506,"height":506,"filesize":450844,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/08.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/08.png","size":"full","id":32,"alt":"","pixels":256036,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 13:05:27', '2022-12-12 13:40:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:30:44', '2022-11-24 11:30:44'),
(44, 'https://js-school-wp.test/wp-content/uploads/2022/11/11.png', '59:991d4140a33f5b7bcfdcb6ecc02c5c7a', 38, 'post', 'attachment', 1, 37, NULL, NULL, '11', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/11.png', NULL, '38', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/11.png', '38', 'attachment-image', '{"width":508,"height":508,"filesize":437265,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/11.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/11.png","size":"full","id":38,"alt":"","pixels":258064,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 13:05:27', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:32:51', '2022-11-24 11:32:51'),
(45, 'https://js-school-wp.test/wp-content/uploads/2022/11/13.png', '59:877376e4ad33077bf5180fd20cc86ecc', 42, 'post', 'attachment', 1, 41, NULL, NULL, '13', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/13.png', NULL, '42', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/13.png', '42', 'attachment-image', '{"width":504,"height":506,"filesize":444449,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/13.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/13.png","size":"full","id":42,"alt":"","pixels":255024,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 13:05:27', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:33:57', '2022-11-24 11:33:57'),
(46, 'https://js-school-wp.test/wp-content/uploads/2022/11/15.png', '59:1e3214fd3ff67a2f1a5b495eca3660ec', 46, 'post', 'attachment', 1, 45, NULL, NULL, '15', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/15.png', NULL, '46', 'attachment-image', NULL, NULL, 'https://js-school-wp.test/wp-content/uploads/2022/11/15.png', '46', 'attachment-image', '{"width":508,"height":508,"filesize":530799,"url":"https:\\/\\/js-school-wp.test\\/wp-content\\/uploads\\/2022\\/11\\/15.png","path":"\\/var\\/www\\/html\\/\\/wp-content\\/uploads\\/2022\\/11\\/15.png","size":"full","id":46,"alt":"","pixels":258064,"type":"image\\/png"}', NULL, NULL, NULL, '2022-11-24 13:05:27', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-11-24 11:35:17', '2022-11-24 11:35:17'),
(49, 'https://js-school-wp.test/team-members/mike-berlin-4/', '53:ac2b1b2e5a75307b31a95cb055599dca', 49, 'post', 'team-member', 1, 0, NULL, NULL, 'Mike Berlin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(50, 'https://js-school-wp.test/team-members/steve-renda-4/', '53:25ce8220f68a91d1ca519a05cef97f7e', 50, 'post', 'team-member', 1, 0, NULL, NULL, 'Steve Renda', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(51, 'https://js-school-wp.test/team-members/sharon-laday-4/', '54:1ecb3e1805d1883f05bf78216cbac6a5', 51, 'post', 'team-member', 1, 0, NULL, NULL, 'Sharon LaDay', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(52, 'https://js-school-wp.test/team-members/dan-silverburg-4/', '56:2dd1a9ffb5a0d1168284d7c35d52876c', 52, 'post', 'team-member', 1, 0, NULL, NULL, 'Dan Silverburg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(53, 'https://js-school-wp.test/team-members/pratyush-rai-4/', '54:8bb2d78d92480423bf96da28696f70ae', 53, 'post', 'team-member', 1, 0, NULL, NULL, 'Pratyush Rai', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(54, 'https://js-school-wp.test/team-members/gareth-hancock-3/', '56:199d50e16a848bd3650f48520d0f41d1', 54, 'post', 'team-member', 1, 0, NULL, NULL, 'Gareth Hancock', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(55, 'https://js-school-wp.test/team-members/jeff-mccarthy-3/', '55:695c01f9e10f702e82bb838e03d4b1e7', 55, 'post', 'team-member', 1, 0, NULL, NULL, 'Jeff McCarthy', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-28 13:19:38', '2022-11-24 13:10:06'),
(56, 'https://js-school-wp.test/team-members/mahendran-jawaharlal-3/', '62:395263e8f748fda148a626794e0c53f8', 56, 'post', 'team-member', 1, 0, NULL, NULL, 'Mahendran Jawaharlal', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(57, 'https://js-school-wp.test/team-members/kevin-pawsey-3/', '54:46cd885d5a27fecf3d5ebb346cbcda20', 57, 'post', 'team-member', 1, 0, NULL, NULL, 'Kevin Pawsey', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(58, 'https://js-school-wp.test/team-members/alex-von-rosenberg-3/', '60:ed9f5a9eec7abf5e490b2f83ad23307b', 58, 'post', 'team-member', 1, 0, NULL, NULL, 'Alex Von Rosenberg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(59, 'https://js-school-wp.test/team-members/andrew-mccann-3/', '55:143e90c6f3e422ee2c63f522c7e8663e', 59, 'post', 'team-member', 1, 0, NULL, NULL, 'Andrew McCann', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(60, 'https://js-school-wp.test/team-members/ovi-jacob-3/', '51:5f0da823a280419bdc3956eb93b12b4b', 60, 'post', 'team-member', 1, 0, NULL, NULL, 'Ovi Jacob', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(61, 'https://js-school-wp.test/team-members/james-caras-ph-d-3/', '58:c612ae31cf9ff678f64fddaf2ada0a8a', 61, 'post', 'team-member', 1, 0, NULL, NULL, 'James Caras, Ph.D.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(62, 'https://js-school-wp.test/team-members/allan-meese-3/', '53:b807d4b42d689c4b1e30f7fa40ee105f', 62, 'post', 'team-member', 1, 0, NULL, NULL, 'Allan Meese', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(63, 'https://js-school-wp.test/team-members/troy-williams-3/', '55:6a7e091b40be9cd185cac8607ab5d257', 63, 'post', 'team-member', 1, 0, NULL, NULL, 'Troy Williams', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:08:26', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:10:06', '2022-11-24 13:10:06'),
(64, 'https://js-school-wp.test/team-members/mike-berlin-2/', '53:bd3c9c5d11710ad1098659e37279a67f', 64, 'post', 'team-member', 1, 0, NULL, NULL, 'Mike Berlin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(65, 'https://js-school-wp.test/team-members/troy-williams-2/', '55:b3e0ae2fc3fb5afed780f820b1079170', 65, 'post', 'team-member', 1, 0, NULL, NULL, 'Troy Williams', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(66, 'https://js-school-wp.test/team-members/allan-meese-2/', '53:2742e12e8a26aa4f4771a4a2fd25a0e8', 66, 'post', 'team-member', 1, 0, NULL, NULL, 'Allan Meese', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(67, 'https://js-school-wp.test/team-members/james-caras-ph-d-2/', '58:1eb67fbaa243951664f36d2c1dea670e', 67, 'post', 'team-member', 1, 0, NULL, NULL, 'James Caras, Ph.D.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(68, 'https://js-school-wp.test/team-members/ovi-jacob-2/', '51:a5c706469109305b5d65567407c8a719', 68, 'post', 'team-member', 1, 0, NULL, NULL, 'Ovi Jacob', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(69, 'https://js-school-wp.test/team-members/andrew-mccann-2/', '55:fcd94c8fb57c58aae5243f12c583412f', 69, 'post', 'team-member', 1, 0, NULL, NULL, 'Andrew McCann', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(70, 'https://js-school-wp.test/team-members/alex-von-rosenberg-2/', '60:2b5ecff1a10bf1768188d2bd64348805', 70, 'post', 'team-member', 1, 0, NULL, NULL, 'Alex Von Rosenberg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(71, 'https://js-school-wp.test/team-members/kevin-pawsey-2/', '54:15e3186af63b33115eb7674dd8be3667', 71, 'post', 'team-member', 1, 0, NULL, NULL, 'Kevin Pawsey', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(72, 'https://js-school-wp.test/team-members/mahendran-jawaharlal-2/', '62:e624ef098f0a53c5e1b2470ad9ec7c2c', 72, 'post', 'team-member', 1, 0, NULL, NULL, 'Mahendran Jawaharlal', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(73, 'https://js-school-wp.test/team-members/steve-renda-3/', '53:315bdb9e8304ea7bc87e2ab4659d4b14', 73, 'post', 'team-member', 1, 0, NULL, NULL, 'Steve Renda', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(74, 'https://js-school-wp.test/team-members/sharon-laday-3/', '54:24f1257ddce9f419a27cb33fdc2d74eb', 74, 'post', 'team-member', 1, 0, NULL, NULL, 'Sharon LaDay', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(75, 'https://js-school-wp.test/team-members/dan-silverburg-2/', '56:9599cca5d6fe25bd4d2f762311745a02', 75, 'post', 'team-member', 1, 0, NULL, NULL, 'Dan Silverburg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(76, 'https://js-school-wp.test/team-members/pratyush-rai-3/', '54:6e98c67253b1fa23953b6237a1eea1cc', 76, 'post', 'team-member', 1, 0, NULL, NULL, 'Pratyush Rai', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(77, 'https://js-school-wp.test/team-members/gareth-hancock-2/', '56:48bf270f426790b4e2c411b41c26e14e', 77, 'post', 'team-member', 1, 0, NULL, NULL, 'Gareth Hancock', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(78, 'https://js-school-wp.test/team-members/jeff-mccarthy-2/', '55:6053f38e331917606834a1bd9ab0198a', 78, 'post', 'team-member', 1, 0, NULL, NULL, 'Jeff McCarthy', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-28 13:20:03', '2022-11-24 13:09:45'),
(79, 'https://js-school-wp.test/team-members/mike-berlin-3/', '53:9d05fe5d06fd2d1881fd93bc17421ab2', 79, 'post', 'team-member', 1, 0, NULL, NULL, 'Mike Berlin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(80, 'https://js-school-wp.test/team-members/steve-renda-2/', '53:538d935ba9414ec87d6ce5868c95967a', 80, 'post', 'team-member', 1, 0, NULL, NULL, 'Steve Renda', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(81, 'https://js-school-wp.test/team-members/sharon-laday-2/', '54:60db6a103d40d10336a19d79262c7a82', 81, 'post', 'team-member', 1, 0, NULL, NULL, 'Sharon LaDay', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(82, 'https://js-school-wp.test/team-members/dan-silverburg-3/', '56:61a3dedbdbbca5e8f16b0c4bdca190d4', 82, 'post', 'team-member', 1, 0, NULL, NULL, 'Dan Silverburg', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-14 08:21:13', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:45', '2022-11-24 13:09:45'),
(83, 'https://js-school-wp.test/team-members/pratyush-rai-2/', '54:3855a62595e8293431b53bb130ce16a6', 83, 'post', 'team-member', 1, 0, NULL, NULL, 'Pratyush Rai', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-24 13:09:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-24 13:09:44', '2022-11-24 13:09:44'),
(84, 'https://js-school-wp.test/', '26:614fccffd8f128d9c9b1a195b86ed841', 84, 'post', 'page', 1, 0, NULL, NULL, 'Homepage', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-25 12:08:15', '2022-12-12 13:40:31', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-11-25 12:08:15', '2022-11-25 12:08:15'),
(85, NULL, NULL, 86, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Tag Options', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:12:55', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-11-29 13:58:05', '2022-11-29 08:12:55'),
(86, NULL, NULL, 87, 'post', 'acf-field', 1, 86, NULL, NULL, 'Followers', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:12:55', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-11-29 08:12:55', '2022-11-29 08:12:55'),
(87, 'https://js-school-wp.test/tag/javascript/', '41:53a9ffb43bf71741ff46804d7adfdc2b', 2, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'javascript', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:15:38', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-11-29 08:21:06'),
(88, 'https://js-school-wp.test/tag/scope/', '36:8e9eed366f1dbf8a966ceb0443a64185', 3, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'scope', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:16:55', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-11-29 08:21:06'),
(89, 'https://js-school-wp.test/tag/closures/', '39:d57faa4e0b4d66322382421955fddfe1', 4, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'closures', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:17:45', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-11-29 08:21:06', '2022-11-29 08:21:06'),
(90, 'https://js-school-wp.test/2022/11/29/how-do-javascript-closures-work/', '69:1abd1a8e03c295b68287ec4fcd545d4f', 88, 'post', 'post', 1, 0, NULL, NULL, 'How do JavaScript closures work?', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-11-29 08:20:04', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2022-11-29 08:21:06', '2022-11-29 08:21:06'),
(91, 'https://js-school-wp.test/2022/12/01/hat-is-the-scope-of-variables-in-javascript/', '81:fdaccec2f7b1a7d5eb3ee857ee7df763', 91, 'post', 'post', 1, 0, NULL, NULL, 'What is the scope of variables in JavaScript?', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:25:29', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2022-12-01 13:28:40', '2022-12-01 13:26:18'),
(92, 'https://js-school-wp.test/tag/function/', '39:ae87397b6f8e4a9870c250b1f58851fb', 5, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'function', NULL, NULL, 0, NULL, NULL, NULL, 'function', 50, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:26:18', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-12-01 13:26:18'),
(93, 'https://js-school-wp.test/tag/variables/', '40:71e429a48b36637391290064e3d0b2d9', 6, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'variables', NULL, NULL, 0, NULL, NULL, NULL, 'variables', 39, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:26:18', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-12-01 13:26:18'),
(94, 'https://js-school-wp.test/tag/let/', '34:94dc2ae81672aa34edb5d5f6daadb0f2', 7, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'let', NULL, NULL, 0, NULL, NULL, NULL, 'let', 32, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:28:12', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:12', '2022-12-01 13:28:12'),
(95, 'https://js-school-wp.test/tag/var/', '34:503ac079b544585deae304e4ce9c44d5', 8, 'term', 'post_tag', NULL, NULL, NULL, NULL, 'var', NULL, NULL, 0, NULL, NULL, NULL, 'var', 39, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:28:12', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-01 13:28:40', '2022-12-01 13:26:18'),
(96, 'https://js-school-wp.test/2022/12/01/what-is-the-difference-between-let-and-var/', '80:760fb8baa76851d5adfb19531c15377c', 94, 'post', 'post', 1, 0, NULL, NULL, 'What is the difference between &#8220;let&#8221; and &#8220;var&#8221;?', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-01 13:28:12', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2022-12-01 13:28:12', '2022-12-01 13:28:12'),
(97, 'https://js-school-wp.test/organizations/massachusetts-institute-of-technology/', '78:fca0417dda69d038062ed605d1690194', 96, 'post', 'organization', 1, 0, NULL, NULL, 'Massachusetts Institute of Technology', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:36:15', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:36:15', '2022-12-02 11:36:15'),
(98, 'https://js-school-wp.test/organizations/harvard-university/', '59:d24c855a387ff4f48e1dc678503f22a0', 97, 'post', 'organization', 1, 0, NULL, NULL, 'Harvard University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:36:24', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:36:24', '2022-12-02 11:36:24'),
(99, 'https://js-school-wp.test/organizations/stanford-university/', '60:ec5337656c850122e195a14df4e0d448', 98, 'post', 'organization', 1, 0, NULL, NULL, 'Stanford University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:36:35', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-02 11:36:35', '2022-12-02 11:36:35'),
(100, 'https://js-school-wp.test/organizations/cornell-university/', '59:19d23dcf294a776ae2e3d04c852254e6', 100, 'post', 'organization', 1, 0, NULL, NULL, 'Cornell University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:36:45', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-02 11:36:45', '2022-12-02 11:36:45'),
(101, 'https://js-school-wp.test/organizations/university-of-california-berkeley/', '74:0860fe0307f35ea944684c7d4d933e86', 101, 'post', 'organization', 1, 0, NULL, NULL, 'University of California, Berkeley', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:37:04', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:37:04', '2022-12-02 11:37:04'),
(102, 'https://js-school-wp.test/organizations/university-of-michigan/', '63:1a2ce6a4063a1376e4652fc2c5c4c17b', 102, 'post', 'organization', 1, 0, NULL, NULL, 'University of Michigan', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:37:20', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:37:20', '2022-12-02 11:37:20'),
(103, 'https://js-school-wp.test/organizations/university-of-washington/', '65:2bd54985b97340896e1df246e76f2eb4', 103, 'post', 'organization', 1, 0, NULL, NULL, 'University of Washington', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:37:28', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-02 11:37:28', '2022-12-02 11:37:28') ;
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(104, 'https://js-school-wp.test/organizations/columbia-university-in-the-city-of-new-york/', '84:6e09e5c93faaa79d0880371e4fcd9100', 104, 'post', 'organization', 1, 0, NULL, NULL, 'Columbia University in the City of New York', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:37:47', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:37:47', '2022-12-02 11:37:47') ;
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(105, 'https://js-school-wp.test/organizations/university-of-california-los-angeles/', '77:1bf0137135aa6170b8caf4e024ec2cee', 105, 'post', 'organization', 1, 0, NULL, NULL, 'University of California, Los Angeles', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:37:51', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:37:51', '2022-12-02 11:37:51'),
(106, 'https://js-school-wp.test/organizations/yale-university/', '56:7fdb2562c20b4e5d2d2530cc4ae08b79', 106, 'post', 'organization', 1, 0, NULL, NULL, 'Yale University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:38:22', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:38:22', '2022-12-02 11:38:22'),
(107, 'https://js-school-wp.test/organizations/university-of-pennsylvania/', '67:942a61eef7c5144db9ec88cb2e917299', 107, 'post', 'organization', 1, 0, NULL, NULL, 'University of Pennsylvania', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:38:39', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:38:39', '2022-12-02 11:38:39'),
(108, 'https://js-school-wp.test/organizations/university-of-minnesota-twin-cities/', '76:0d785f640a9988dcbac44f0b9fde928f', 108, 'post', 'organization', 1, 0, NULL, NULL, 'University of Minnesota-Twin Cities', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:38:50', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:38:50', '2022-12-02 11:38:50'),
(109, 'https://js-school-wp.test/organizations/university-of-wisconsin-madison/', '72:66f00c161fd6b4450b7da55da6386389', 109, 'post', 'organization', 1, 0, NULL, NULL, 'University of Wisconsin-Madison', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:39:00', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:39:00', '2022-12-02 11:39:00'),
(110, 'https://js-school-wp.test/organizations/the-university-of-texas-at-austin/', '74:82928fe614541ac399bc443537fc6f79', 110, 'post', 'organization', 1, 0, NULL, NULL, 'The University of Texas at Austin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:39:11', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:39:11', '2022-12-02 11:39:11'),
(111, 'https://js-school-wp.test/organizations/johns-hopkins-university/', '65:3ececabe165afffa0a603090a8d015e9', 111, 'post', 'organization', 1, 0, NULL, NULL, 'Johns Hopkins University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:39:21', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:39:21', '2022-12-02 11:39:21'),
(112, 'https://js-school-wp.test/organizations/princeton-university/', '61:fa0bd599d86281b551254164c0d8f95d', 113, 'post', 'organization', 1, 0, NULL, NULL, 'Princeton University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:41:38', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:41:38', '2022-12-02 11:41:38'),
(113, 'https://js-school-wp.test/organizations/university-of-chicago/', '62:b76a73c51cb4c512dd799d438e69f905', 114, 'post', 'organization', 1, 0, NULL, NULL, 'University of Chicago', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:41:44', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:41:44', '2022-12-02 11:41:44'),
(114, 'https://js-school-wp.test/organizations/purdue-university/', '58:16229e285e078b8868633cdf6ea0631d', 115, 'post', 'organization', 1, 0, NULL, NULL, 'Purdue University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:42:09', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:42:09', '2022-12-02 11:42:09'),
(115, 'https://js-school-wp.test/organizations/university-of-california-san-diego/', '75:e5309b4e3987a10d3a6c1ed678a55e28', 116, 'post', 'organization', 1, 0, NULL, NULL, 'University of California, San Diego', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:42:21', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:42:21', '2022-12-02 11:42:21'),
(116, 'https://js-school-wp.test/organizations/new-york-university/', '60:25ed0308df28461b427a9714390f0753', 117, 'post', 'organization', 1, 0, NULL, NULL, 'New York University', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-12-02 11:42:35', '2022-12-13 10:48:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2022-12-02 11:42:35', '2022-12-02 11:42:35'),
(117, NULL, NULL, NULL, 'post-type-archive', 'organization', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Organizations', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-02 13:25:41', '2022-12-12 13:39:42', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-12-02 11:42:35', '2022-12-02 11:36:15'),
(119, 'https://js-school-wp.test/team-members/', '39:32b71b5851012582cb05679c6d6ada8e', NULL, 'post-type-archive', 'team-member', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Team Members', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:40:36', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-11-28 13:20:25', '2022-11-24 11:24:35'),
(120, 'https://js-school-wp.test/organizations/', '40:e653670a795df60220ff3c8d85749b67', NULL, 'post-type-archive', 'organization', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Organizations', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-12 13:40:36', '2022-12-12 13:40:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-12-02 11:42:35', '2022-12-02 11:36:15') ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(1, 0, 0, 1),
(4, 0, 0, 1),
(5, 0, 0, 1),
(9, 0, 0, 1),
(10, 0, 0, 1),
(11, 0, 0, 1),
(12, 0, 0, 1),
(13, 0, 0, 1),
(14, 0, 0, 1),
(17, 0, 0, 1),
(18, 17, 1, 1),
(19, 0, 0, 1),
(20, 19, 1, 1),
(21, 0, 0, 1),
(22, 21, 1, 1),
(23, 0, 0, 1),
(24, 0, 0, 1),
(25, 24, 1, 1),
(26, 0, 0, 1),
(27, 26, 1, 1),
(28, 0, 0, 1),
(29, 28, 1, 1),
(30, 0, 0, 1),
(31, 0, 0, 1),
(32, 31, 1, 1),
(33, 0, 0, 1),
(34, 33, 1, 1),
(35, 0, 0, 1),
(36, 0, 0, 1),
(37, 36, 1, 1),
(38, 0, 0, 1),
(39, 0, 0, 1),
(40, 39, 1, 1),
(41, 0, 0, 1),
(42, 23, 1, 1),
(43, 30, 1, 1),
(44, 35, 1, 1),
(45, 38, 1, 1),
(46, 41, 1, 1),
(49, 0, 0, 1),
(50, 0, 0, 1),
(51, 0, 0, 1),
(52, 0, 0, 1),
(53, 0, 0, 1),
(54, 0, 0, 1),
(55, 0, 0, 1),
(56, 0, 0, 1),
(57, 0, 0, 1),
(58, 0, 0, 1),
(59, 0, 0, 1),
(60, 0, 0, 1),
(61, 0, 0, 1),
(62, 0, 0, 1),
(63, 0, 0, 1),
(64, 0, 0, 1),
(65, 0, 0, 1),
(66, 0, 0, 1),
(67, 0, 0, 1),
(68, 0, 0, 1),
(69, 0, 0, 1),
(70, 0, 0, 1),
(71, 0, 0, 1),
(72, 0, 0, 1),
(73, 0, 0, 1),
(74, 0, 0, 1),
(75, 0, 0, 1),
(76, 0, 0, 1),
(77, 0, 0, 1),
(78, 0, 0, 1),
(79, 0, 0, 1),
(80, 0, 0, 1),
(81, 0, 0, 1),
(82, 0, 0, 1),
(83, 0, 0, 1),
(84, 0, 0, 1),
(85, 0, 0, 1),
(87, 0, 0, 1),
(88, 0, 0, 1),
(89, 0, 0, 1),
(90, 0, 0, 1),
(91, 0, 0, 1),
(92, 0, 0, 1),
(93, 0, 0, 1),
(94, 0, 0, 1),
(95, 0, 0, 1),
(96, 0, 0, 1),
(97, 0, 0, 1),
(98, 0, 0, 1),
(99, 0, 0, 1),
(100, 0, 0, 1),
(101, 0, 0, 1),
(102, 0, 0, 1),
(103, 0, 0, 1),
(104, 0, 0, 1),
(105, 0, 0, 1),
(106, 0, 0, 1),
(107, 0, 0, 1),
(108, 0, 0, 1),
(109, 0, 0, 1),
(110, 0, 0, 1) ;
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(111, 0, 0, 1),
(112, 0, 0, 1),
(113, 0, 0, 1),
(114, 0, 0, 1),
(115, 0, 0, 1),
(116, 0, 0, 1) ;

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_primary_term`
#

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(2, 'http://en.wikipedia.org/wiki/Scheme_%28programming_language%29', 88, NULL, 'external', 90, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/let', 94, NULL, 'external', 96, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

